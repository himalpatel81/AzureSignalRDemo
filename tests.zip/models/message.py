"""
Data models for TextAnalyzer AI category Engine
"""

from dataclasses import dataclass, asdict, is_dataclass, fields
from typing import List, Dict, Any, Optional 
from enum import Enum 
import json
import uuid 
import time

from pydantic import BaseModel, Field, field_validator, model_validator


class MessageCategory(Enum): 
    'SMS message categories' 
    GENERAL = "general" 
    POLITICAL = "political" 
    NOT_FOR_PROFIT = "notforprofit"

class ComplianceLevel(Enum): 
    """Guideline compliance levels""" 
    MANDATORY = "mandatory" 
    RECOMMENDED ="recommended" 
    OPTIONAL = "optional" 

class GuidelineSeverity(Enum): 
    """Guideline violation severity levels""" 
    LOW =  "low" 
    MEDIUM = "medium" 
    HIGH = "high" 
    CRITICAL = "critical" 

@dataclass
class GuidelineExample: 
    """Example for guideline compliance (effective or ineffective) """
    text: str 
    explanation: str 
    compliance_score: int 
    violations: Optional[List[str]] = None

    def _post_init__(self): 
        """Validate example data after initialization""" 
        if not self.text or not self.text.strip(): 
            raise ValueError("Example text cannot be empty") 
        if not self.explanation or not self.explanation.strip(): 
            raise ValueError ("Example explanation cannot be empty") 
        if self.compliance_score < 0 or self.compliance_score > 100: 
            raise ValueError("Compliance score must be between 0 and 100")

@dataclass 
class ValidationCriterion: 
    """Validation criterion for guideline compliance"""
    criterion: str 
    description: str 
    check_method: str
    def __post_init__(self):
        """Validate criterion data after initialization""" 
        if not self.criterion or not self.criterion.strip(): 
            raise ValueError("Criterion name cannot be empty") 
        if not self.description or not self.description.strip(): 
            raise ValueError("Criterion description cannot be empty") 
        if not self.check_method or not self.check_method.strip():
            raise ValueError("Criterion check method cannot be empty") 
         
@dataclass
class Guideline:
    """New format guideline model for message compliance checking""" 
    rule_id: str 
    rule_title: str 
    rule_statement: str 
    detailed_description: str 
    compliance_level: str 
    severity: str 
    validation_criteria: List[ValidationCriterion]
    best_practices: List[str] 
    effective_examples: List[GuidelineExample] 
    ineffective_examples: List[GuidelineExample] 
    compliance_benefits: Optional[List[str]] = None#TODO

    def __post_init__(self): 
        """Validate guideline data after initialization""" 
        if not self.rule_id or not self.rule_id.strip(): 
            raise ValueError("Rule ID cannot be empty") 
        if not self.rule_title or not self.rule_title.strip():
            raise ValueError("Rule title cannot be empty")
        if not self.rule_statement or not self.rule_statement.strip(): 
            raise ValueError("Rule statement cannot be empty")
        if self.compliance_level not in [c.value for c in ComplianceLevel]: 
            raise ValueError(f"Invalid compliance level: (self.compliance_level)") 
        if self.severity not in [s.value for s in GuidelineSeverity]: 
            raise ValueError(f"Invalid severity level: (self.severity)")
    
    def get_id(self) -> str: 
        """Get the guideline ID"""
        return self.rule_id
    
    def get_title(self) -> str: 
        """Get the guideline title""" 
        return self.rule_title
    
    def get_statement(self) -> str: 
        """Get the guideline statement""" 
        return self.rule_statement

    def get_description(self) -> str: 
        """Get the guideline description""" 
        return self.detailed_description
    
    def get_compliance_level(self) -> str: 
        """Get the guideline compliance level""" 
        return self.compliance_level
    
    def get_severity(self) -> str: 
        """Get the guideline severity""" 
        return self.severity
    
    def get_validation_criteria(self) -> List[ValidationCriterion]: 
        """Get the guideline validation Criteria""" 
        return self.validation_criteria
    
    def get_best_practices(self) -> List[str] : 
        """Get the guideline Best Practices""" 
        return self.best_practices

    def get_effective_examples(self) -> List[GuidelineExample] : 
        """Get the guideline Effective Example""" 
        return self.effective_examples

    def get_ineffective_examples(self) -> List[GuidelineExample] : 
        """Get the guideline Ineffective Example""" 
        return self.ineffective_examples
    
    
    def get_priority(self) -> int: 
        """Estimate priority based on severity and compliance level""" 
        severity_priority = {"low": 3, "medium": 5, "high": 7, "critical": 9} 
        compliance_priority = {"optional": 1, "recommended": 2, "mandatory": 3}
        base_priority = severity_priority.get(self.severity, 5) 
        compliance_bonus = compliance_priority.get(self.compliance_level, 1)
        return min(10, base_priority + compliance_bonus)


@dataclass
class MMSImage:
    """TODO"""
    image_data: str
    mime_type: str
    file_name: Optional[str] = None

    def get_data_url(self) -> str:
        """Get data URL for the image"""
        return f"data:{self.mime_type};base64,{self.image_data}"

@dataclass
class MMSEmoji:    
    """TODO"""
    emoji: str
    unicode_code: str
    description: Optional[str] = None


@dataclass
class MMSContent:
    """TODO"""    
    text:str
    images: List[MMSImage] = None
    emojis: List[MMSEmoji] = None

    def has_multimedia(self) -> bool:
        """todo"""
        return len(self.images) > 0 or len(self.emojis) >0
    
    def get_total_size_estimate(self) -> int:
        """todo"""
        size = len(self.text.encode('utf-8'))

        for image in self.images:
            size += len(image.image_data) * 3 // 4
        
        for emoji in self.emojis:
            size += len(emoji.emoji.encode('utf-8'))
        
        return size


@dataclass
class MMSAnalysisRequest: 
    """Request model for MMS Analysis""" 
    content: MMSContent 
    category: str # User-provided category: "Political", "NotForProfit", or "General" 
    session_id: Optional[str] = None

    def __post_init__(self):
        """Validate MMS request data after initialization""" 
        
        if not self.content: 
            raise ValueError("MMS content cannot be empty")
        
        if not self.category or self.category not in [c.value for c in MessageCategory]: 
            raise ValueError(f"Invalid category: (self.category). Must be one of: {[c.value for c in MessageCategory]}")

        # Generate session ID if not provided 
        if not self.session_id: 
            timestamp = int(time.time()) 
            self.session_id = f"mms-session-{timestamp}-{str(uuid.wid4())[:8]}"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MMSAnalysisRequest': 
        """Create MMSAnalysisRequest from dictionary"""
        # Parse content 
        content_data = data['content']

        # Parse images
        images = []
        for img_data in content_data.get('images', []): 
            images.append(MMSImage(
                image_data =  img_data['image_data'], 
                mime_type=img_data['mime_type'], 
                file_name=img_data.get('file_name')
            ))

        # Parse emojis
        emojis = []
        for emoji_data in content_data.get('emojis', []): 
            emojis.append(MMSEmoji( 
                emoji=emoji_data['emoji'], 
                unicode_code=emoji_data['unicode_code'], 
                description=emoji_data.get('description')
            ))

        # Create MMS content
        mms_content = MMSContent(
            text=content_data['text'], 
            images=images,
            emojis=emojis
        )
        
        return cls(
            content=mms_content,
            category=data['category'].lower(), 
            session_id=data.get('session_id')
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert MMScategoryRequest to dictionary"""
        return {
            'content':{
                'text': self.content.text,
                'images': [asdict(img) for img in self.content.images],
                'emojis': [asdict(emoji) for emoji in self.content. emojis]
            },
            'category': self.category,
            'session_id': self.session_id
        }

# @dataclass
# class AnalysisResult: 
#     """Complete Analysis result""" 
#     success: bool 
#     category: str 
#     confidence_score: float 
#     explanation: str 
#     #confidence_breakdown: ConfidenceBreakdown 
#     #guideline_analysis: List[GuidelineAnalysis] 
#     violations: List[str] 
#     processing_time_ms: int  
#     suggested_message: Optional[MessageSuggestion] = None 
#     error_message: Optional[str] = None

#     def __post_init__(self): 
#         """Validate result data after initialization""" 
#         if self.confidence_score < 0.0 or self.confidence_score > 1.0: 
#             raise ValueError("Confidence score must be between 0.0 and 1.0")

#         if self.category not in [c.value for c in MessageCategory]: 
#             raise ValueError(f"Invalid category: {self.category}")
        
#         if self.processing_time_ms < 0: 
#             raise ValueError ("Processing time cannot be negative")
        
#         if not self.success and not self.error_message: 
#             raise ValueError ("Error message required when success is False")
        
#     def to_dict(self) -> Dict[str, Any]:
#         """Convert AnalysisResult to dictionary"""
#         result = {
#             'success': self.success,
#             'category': self.category, 
#             'confidence_score': self.confidence_score,
#             'explanation': self.explanation,
#             #'confidence_breakdown': asdict(self.confidence_breakdown),
#             #'guideline_analysis': [asdict(ga) for ga in self.guideline_analysis],
#             'violations': self.violations,
#             'processing_time_ms': self.processing_time_ms
#         }

#         if self.suggested_message:
#             result['suggested_message'] = asdict(self.suggested_message)

#         if self.error_message:
#             result['error_message']=self.error_message

#         return result

#     def to_json(self) -> str:
#         """Convert AnalysisResult to JSON string"""
#         return json.dumps(self.to_dict(), indent=None, separators=(',', ':'))

class Serializable:
    def to11_dict(self):
        def serialize(obj):
            if is_dataclass(obj):
                result = {}
                for f in fields(obj):
                    value = getattr(obj, f.name)
                    result[f.name] = serialize(value)
                return result
            elif isinstance(obj, list):
                return [serialize(item) for item in obj]
            elif isinstance(obj, dict):
                return {k: serialize(v) for k, v in obj.items()}
            else:
                return obj
        return serialize(self)

    def to11_json(self, indent=None):
        return json.dumps(self.to_dict(), indent=indent, separators=(',', ':'))

class Change(BaseModel):
    """Represents a specific change made to improve message compliance and effectiveness. Used to track modifications applied during message optimization process."""
    type: str = Field(
        ...,
        description="The category or type of change made to the message This helps categorize the nature of the modification for analysis and reporting purposes."
    )
    description: str = Field(
        ...,
        description="A detailed explanation of what specific change was made to the message, describing both the problem identified and the solution applied. Should be clear and specific enough for users to understand the modification and its rationale."
    )


class GuidelineApplication(BaseModel):
    """Represents how a specific guideline was applied to improve message compliance. Links guidelines to their practical benefits in message optimization."""
    guideline: str = Field(
        description="The name or identifier of the specific guideline that was applied to improve the message. This should match the guideline names from the system's guideline database."
    )
    benefit: str = Field(
        description="A clear explanation of the specific benefit or improvement achieved by applying this guideline, describing how it enhances compliance, clarity, or effectiveness. Should focus on the practical value delivered to the user."
    )


class ContentValidation(BaseModel):
    """Validation results for a specific type of content (text, images, or emojis). Provides detailed assessment of compliance and identifies specific issues."""
    compliance: str = Field(
        ...,
        description="Overall compliance status for this content type. Should be one of: 'compliant', 'non-compliant', 'partially_compliant', or 'requires_review'. This provides a quick assessment of whether the content meets regulatory and guideline requirements."
    )
    issues: List[str] = Field(
        default_factory=list,
        description="A list of specific compliance issues, violations, or concerns identified in this content type. Each item should be a clear, actionable description of a problem that needs to be addressed (e.g., 'Missing sender identification', 'Inappropriate image content', 'Offensive emoji usage')."
    )


class ValidationResults(BaseModel):
    """Comprehensive validation results for all content types in a multimodal message. Provides detailed breakdown of compliance assessment across different media types."""
    text_content: ContentValidation = Field(
        description="Detailed validation results specifically for the text portion of the message, including compliance status and any text-related issues such as missing sender identification, unclear purpose, inappropriate language, or regulatory violations."
    )
    image_content: ContentValidation = Field(
        description="Detailed validation results for any images in the message, assessing visual content for appropriateness, compliance with advertising standards, accessibility considerations, and alignment with message purpose and system guidelines."
    )
    emoji_content: ContentValidation = Field(
        description="Detailed validation results for emoji usage in the message, evaluating appropriateness, professional context uitability, cultural sensitivity, and whether emojis enhance or detract from the message's clarity and effectiveness."
    )
    
class MultimodalCoherence(BaseModel):
    """Assessment of how well different content types work together in a multimodal message. Evaluates the harmony and consistency between text, images, and emojis."""
    text: str = Field(
        description="Assessment of how well the text content supports and aligns with the overall message purpose, tone, and branding. Should evaluate clarity, consistency, and effectiveness in conveying the intended message while maintaining compliance standards."
    )
    images: str = Field(
        description="Evaluation of how effectively the images support the text content and overall message goals. Should assess visual-textual alignment, appropriateness of imagery, and whether images enhance message understanding and engagement without creating confusion or compliance issues." 
    )
    emojis: str = Field(
        description="Analysis of how well emojis complement both text and images to create a cohesive message experience. Should evaluate whether emoji usage enhances communication effectiveness, maintains professional appropriateness, and supports rather than distracts from the core message."
    )


class ComplianceAnalysis(BaseModel):
    """Comprehensive compliance analysis across all content types in the message. Provides detailed assessment of regulatory and guideline adherence."""
    text_content: ContentValidation = Field(
        description="In-depth compliance analysis of text content against relevant regulations , industry guidelines, and best practices. Identifies violations, compliance gaps, and areas requiring attention for legal and regulatory adherence as per the system guideline."
    )
    image_content: ContentValidation = Field(
        description="Detailed compliance assessment of visual content including copyright considerations, appropriatene standards, accessibility requirements, and alignment with advertising regulations and industry-specific compliance requirements."
    )
    emoji_content: ContentValidation = Field(
        description="Comprehensive evaluation of emoji usage for compliance with professionai communication standards, cultural sensitivity requirements, and appropriateness in the given context category."
    )

class ResponseFormat(BaseModel):
    """Comprehensive response format for TextAnalyzer AI classification and optimization results. This is the main output structure containing all analysis results and recommendations."""
    success: bool = Field(
        ...,
        description="Boolean indicator of whether the analysis was completed successfully. True indicates successful processing and analysis completion, while False indicates an error or failure occurred during processing that prevented complete analysis"
    )

    violations: List[str] = Field(
        default_factory=list,
        #description="array of specific violations found across all content types"
        description="A comprehensive list of all violations, guideline breaches, and issues identified in the message. Each violation should be clearly described with specific details about what rule was violated, why it's problematic, and the potential impact or risk level associated with the violation."
    )
    suggested_message: str = Field(
        description="An optimized, compliant version of the original message that addresses all identified violations and improves overall effectiveness. This should be a complete, ready-to-use message that maintains the original intent while ensuring full compliance with relevant guidelines and regulations."
    )
    justification: str = Field(
        description="A detailed explanation of why the suggested message is an improvement over the original, specifically describing how each change addresses compliance issues, improves clarity, enhances effectiveness, or reduces regulatory risk. Should provide clear reasoning for all modifications made."
    )

    improvement_areas: List[str] = Field(
        default_factory=list,
        description="Give clear actionable list of todos following given guidelines to improve the message."
    )

    compliance_improvements: List[str] = Field(
        default_factory=list,
        description="Specific compliance-focused improvements made to the message, detailing how particular regulatory requirements or guidelines were addressed. Each item should clearly state what compliance issue was resolved and how the solution was implemented."
    )
    impact_score: float = Field(
        ge=0.0, 
        le=1.0, 
        description="A numerical score between 0.0 and 1.0 representing the expected improvement in message effectivenes and compliance achieved through optimization. Higher scores indicate greater improvement in message quality, compliance adherence, and expected recipient engagement."
    )
    changes_made: List[Change] = Field( default_factory=list,
        description="A detailed list of all specific changes made to transform the original message into the optimized version. Each change should specify the type of modification and provide a clear description of what was altered and why, enabling users to understand the optimization process."
    )
    guideline_applications: List[GuidelineApplication] = Field(
        default_factory=list, 
        description="A list documenting which specific guidelines were    applied during optimization and what benefits each guideline provided. This helps users understand the regulatory and best practice foundations behind the improvements made to their message."
    )
    validation_results: ValidationResults = Field(
        default_factory=list,
        description="Comprehensive validation results breaking down compliance assessment by content type (text, images, emojis). Provides detailed analysis of how each media type in the message performs against compliance standards and identifies specific issues that need attention."
    )
    multimodal_coherence: MultimodalCoherence = Field(
        description="Assessment of how well different content types work together in the message to create a cohesive, effective communication. Evaluates the harmony between text, images, and emojis and identifies areas where multimodal integration could be improved."
    )
    compliance_analysis: ComplianceAnalysis = Field(
        description="In-depth compliance analysis across all content types, providing detailed regulatory and guideline adherence assessment. This field contains comprehensive evaluation of legal compliance, industry standards adherence, and best practice alignment for the entire message."
    )
    readability_score: float = Field(
        ge=0.0, 
        le=1.0, 
        description="A numerical score between 0.0 and 1.0 indicating how easy the message is to read and understand. Higher scores represent better readability, considering factors like sentence structure, vocabulary complexity,clarity of expression, and overall comprehension ease."
    )
    confidence_score: float = Field(
        ge=0.0, 
        le=1.0, 
        description="A numerical score between 0.0 and 1.0 representing the system's confidence in the accuracy and reliability of the analysis and recommendations provided. Higher scores indicate greater confidence in the classification results and optimization suggestions."
    )
    #processing_time_ms: int  
	

    # @field_validator('suggested_message')
    # @classmethod
    # def validate_suggested_message(cls,v):
    #     """Validate Suggested Message"""
    #     if not v.strip():
    #         raise ValueError('Suggested message cannot be empty')
    #     return v.strip()
    
    # @model_validator(mode='after')
    # def validate_model(self):
    #     """Model level validation"""
    #     if self.confidence_score is None:
    #         self.confidence_score = 0.5
        
    #     return self
    
    # model_config = {
    #     "extra":"forbid",
    #     "str_strip_whitespace": True,
    #     "validate_assignment": True,
    #     "use_enum_values": True
    # }
    
class HealthResponse(BaseModel):
    """Response model for health check endpoint.
    
    Attributes:
        status: Current status of the service (e.g., 'OK', 'WARNING', 'ERROR')
        timestamp: ISO 8601 timestamp of when the health check was performed
        version: Current version of the service
        uptime_seconds: Number of seconds the service has been running continuously
    """
    status:str
    timestamp: str
    version:str
    uptime_seconds: float

class Category(BaseModel):
    """Cateogry"""
    name: str
    fileName:str
    active: bool

    class Config:
        extra = "allow"

class CategoryLoader(BaseModel):
    """Model for main category file"""
    categories: List[Category]
    