"""
Configuration management
"""
import os
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

class Config(BaseSettings):
    """Application configuratoin with environment variable support"""

    #Open AI Configuration
    openai_api_key: str = Field(
        default="",
        env="OPEN_API_KEY",
        description="OpenAI API Key for GPT Model access"
    )

    openai_api_baseurl: str = Field(
        default="",
        env="OPEN_API_BASEURL",
        description="OpenAI API BASE URL for GPT Model access"
    )

    openai_model: str = Field(
        default="",
        env="OPEN_API_MODEL",
        description="OpenAI API Model To use"
    )

    log_level: str = Field(
        default="INFO",
        env="LOG_LEVEL",
        description="Logging Level (DEBUG, INFO, WARNING, ERROR,CRITICAL)"
    )

    log_file: Optional[str] = Field(
        default=None,
        env="LOG_FILE",
        description="Optional Log file Path"
    )

    #API Key Authentication Configuration 
    api_keys: str = Field(
        default="dev-key-12345,test-key-67890", 
        env="API_KEYS",
        description="Comma-separated list of valid API keys for authentication"
    )

    api_key_header: str = Field(
        default="X-API-Key", 
        env="API_KEY_HEADER", 
        description="HTTP header name for API key authentication"
    )
    
    enable_authentication: bool = Field(
        default=True, 
        env="ENABLE_AUTHENTICATION", 
        description="Enable API key authentication for all endpoints"
    )

    authentication_error_detail: bool = Field(
        default=False,
        env="AUTHENTICATION_ERROR_DETAIL", 
        description="Include detailed error messages in authentication failures"
    )

    class Config:
        env_file=".env"
        env_file_encoding="utf-8"
        case_sensitive=False
    
    def get_valid_api_keys(self) -> List[str]:
        """Get is of valid API keys from configuration"""
        if not self.api_keys:
            return []
        return [key.strip() for key in self.api_keys.split(",") if key.strip ()]
    
    def is_valid_api_key(self, api_key: str)->bool:
        """Check if provided APL key is valid """
        if not self. enable_authentication:
            return True
        valid_keys = self.get_valid_api_keys()
        return api_key in valid_keys
    
    def get_authentication_config(self) -> Dict[str, Any]:
        """First quethen on consumption as dictionary"""
        return {
            "enabled": self.enable_authentication,
            "header_name": self.api_key_header,
            "valid_keys_count": len(self.get_valid_keys()),
            "detailed errors": self.authentication_error_detail
        }


#Global Configuration Instance
config = Config()

if not config.openai_api_key:
    raise ValueError("OPEN_API_KEY environment variable must be set.")