"""
OpenAI API service for Textanalyzer AI Engine
"""

import json
import asyncio
from typing import Dict,List,Optional, Tuple
from openai import OpenAI, AsyncOpenAI
import structlog

from models.message import(
    MessageCategory,
    ResponseFormat
)
from config import Config

from utils.logger import (log_error_with_context)

class OpenAIService:
    """Servicefor handling OpenAI API interactions"""

    def __init__(self, config:Config):
        self.config = config
        self.logger = structlog.get_logger("openai_service")

        #Initialize Open AI client
        self.client = AsyncOpenAI(
            api_key=config.openai_api_key,
            #base_url=config.openai_api_baseurl,
            #timeout
            max_retries = 3
        )

        self.logger.info(
            "OpenAI service initalized",
            model=config.openai_model
            # ,
            # timeout=config.open
        )


    async def analyze_mms_content(
            self, 
            content_text: str,
            images: List, 
            emojis: List, 
            category: str, 
            guidelines: List
    ) -> ResponseFormat:
        """
        Analyze MMS content using OpenAI's standard API with multimodal support

        Args:
            content_text: Text content of the MMS 
            images: List of MMSImage objects 
            emojis: List of MMSEmoji objects 
            category: User-provided category
            guidelines: Applicable guidelines
        
        Returns:
            Comprehensive analysis result
        """
        try:
            # Build multimodal prompt
            prompt = self._build_mms_analysis_prompt(
                content_text, images, emojis, category, guidelines
            )
            # print("\nprompt=" + prompt + "\n")
            # print("\ncontent_text=" + content_text + "\n")
            # print("\ncategory=" + category + "\n")
            # print(f"\nGuidelines Count: {len(guidelines)}\n")

            system_prompt = self._get_mms_system_prompt()
            # print("\nSystem Prompt: " + system_prompt + "\n")
            # Build multimodal messages
            messages = [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user" ,
                    "content": prompt
                }
            ]
            #Add images to the user message if present 
            if images: 
                # Create multimodal content array 
                content_array = [{"type": "text", "text": prompt}]
            
                #Add each image 
                for image in images: 
                    content_array.append({
                        "type": "image_url",
                        "image_url":{
                            "url": image.get_data_url()
                        }
                    })
            
                # Update the user message with multimodal content 
                messages[1]["content"]= content_array

            # log_openai_request(
            # self.logger, self.config.openai_model, len(prompt), "mms_analysis"
            
            response = await self.client.chat.completions.parse(
                model=self.config.openai_model,
                messages=messages, 
                temperature=0.1, # Low temperature for consistent analysis 
                max_tokens=10000, 
                response_format=ResponseFormat
            )
            
            #Handle potential refusal
            if response.choices[0].message.refusal:
                raise ValueError(f"OpenAI refused to process: {response.choices[0].message.refusal}")
            
            content = response.choices[0].message.parsed 
            print(content)
            # log_openai_response(
            # self.logger, self.config.openai_model, len(content),
            # response.usage.total_tokens if response.usage else None
            return content
            
        except Exception as e:
            log_error_with_context(
                self.logger,
                e,
                {
                    "text_length": len(content_text), 
                    "image_count": len(images), 
                    "emoji_count": len(emojis), 
                    "category": category
                },
                "analyze_mms_content"
            )
            raise

    def _get_mms_system_prompt(self) -> str: 
        """Get system prompt for MMS analysis"""
        return """You are an expert MMS (Multimedia Messaging Service) optimizer with deep expertise in multimodal content analysis, compliance validation, communication effectiveness, regulatory and optimization. 
                adherence: Your task is to analyze MMS messages containing text, images, and emojis for better compliance, readibility and impact while maintaining original intent and meaning.

**Analysis And Optimization Framework:**
1.  *Multimodal Content Analysis**
    - Analyze text content for meaning, intent, and compliance
    - Examine images for visual elements, text content, and regulatory compliance
    - Evaluate emojis for context, appropriateness, and cultural sensitivity
    - Assess cross-modal coherence and consistency

2.  **Comprehensive Compliance Validation**
    - Check for multimodal compliance issues (text-image conflicts, inappropriate combinations)
    - Ensure strict adherence to all provided guidelines and rule statements
    - Address specific compliance levels (mandatory, recommended, optional)
    - Resolve violations based on severity levels (critical, high, medium, low)
    - Apply validation criteria systematically

3.  **Optimization Recommendations*
    - Suggest text improvements for clarity and compliance
    - Recommend image optimizations or replacements
    - Propose emoji alternatives for better engagement or compliance
    - Provide cross-modal optimization suggestions

4.  #*Evidence-Based Optimization**
    - Use effective examples as positive patterns to follow
    - Learn from ineffective examples to avoid common pitfalls
    - Apply validation criteria to ensure comprehensive compliance
    - Consider compliance.benefits when making improvements
    - Integrate provided best practices into message optimization
    - Leverage compliance benefits to enhance message value

5.  **Quality Enhancement**
    - Improve readability and comprehension
    - Enhance message effectiveness and impact
    - Optimize length while preserving meaning
    - Maintain appropriate professional tone

"violations": "array of specific violations found across all content types"
"compliance_analysis": "detailed analysis of guideline adherence for each guideline in JSON format"
"changes_made": "array of objects with "type" and "description" of changes"
"guideline_applications": "array of guidelines applied with their benefits"
"validation_results": "compliance validation against provided criteria"
"multimodal_coherence": "analysis of how text, images, and emojis work together (JSON object)",
"success": "set as true if no error during operation."

    **Core Principle:** Provide comprehensive, actionable analysis that considers all aspects of multimodal communication while maintaining the original message intent and improving overall effectiveness."""
    
    def _build_mms_analysis_prompt(
            self, 
            content_text: str, 
            images: List, 
            emojis: List, 
            category: str, 
            guidelines: List
    ) -> str:
        """Build comprehensive MMS analysis prompt"""
        
        # Build emoji analysis section 
        emoji_text = ""
        if emojis: 
            emoji_text ="\n\n**Emojis in Message:**\n"
            for emoji in emojis:
                emoji_text += f"- (emoji.emoji> (Unicode: {emoji.unicode_code})"
            if emoji.description:
                emoji_text += f" -{emoji.description}"
            emoji_text + "In"
        
        # Build image analysis section
        image_text =""
        if images:
            image_text = f"In\n**Images in Message:** (len(images)) image(s) attached\n"
            # for i, image in enumerate(images, 1):
            #     image_text + f". Image {i}: {image.mime_type}"
            image_text += "\n"

        # Build guidelines section
        guidelines_text = ""
        if guidelines:
            guidelines_text = "\n\n**Applicable Guidelines:#*\n"
            for i, guideline in enumerate(guidelines, 1):
                guidelines_text += f"\n--- Guideline {i} ---\n"
                guidelines_text += f". Rule ID: {guideline.get_id()}\n"
                guidelines_text += f". Title: {guideline.get_title()}\n"
                guidelines_text += f". Description: {guideline.get_description()}\n"
                guidelines_text += f". Statement: {guideline.get_statement()}\n"
                guidelines_text += f". Compliance Level: {guideline.get_compliance_level()}\n"
                guidelines_text += f". Severity: {guideline.get_severity()}\n"

        # Add validation criteria
        validation_criteria = guideline.get_validation_criteria()
        if validation_criteria:
            guidelines_text += f". Validation Criteria:\n"
            for criteria in validation_criteria:
                guidelines_text += f" - {criteria.criterion}: {criteria.description} \n"
        
        # Add Best Practices
        best_practices = guideline.get_best_practices()
        if best_practices:
            guidelines_text += f". Best Practices:\n"
            for bestpractice in best_practices:
                guidelines_text += f" - {bestpractice}\n"

        #Effective Example
        effectice_example = guideline.get_effective_examples()
        if effectice_example:
            guidelines_text += f". Effective Example:\n"
            for example in effectice_example:
                guidelines_text += f" - {example.text}: {example.explanation} \n"
        
        #Ineffective Example
        ineffectice_example = guideline.get_ineffective_examples()
        if ineffectice_example:
            guidelines_text += f". Ineffective Example:\n"
            for example in ineffectice_example:
                guidelines_text += f" - {example.text}: {example.explanation} \n"

        return f"""Please analyze this MMS message for compliance, optimization, and multimodal coherence:

**Message Category** {category}

**Text Content:**
"{content_text}"

**Text Analysis:**

Length: {len(content_text)} characters
- Word count: {len(content_text.split())} words
{emoji_text}{image_text}{guidelines_text}

""Analysis instructions:""
1. **Multimodal Analysis:"* Examine how text, images, and emojis work together 
2. *"Compliance Validation:** Check all content against provided guidelines
3. **Cross-Modal Coherence:** Ensure consistency across all content types
4. **Optimization Opportunities:** Identify improvements for each content type
5. **Risk Assessment:** Evaluate potential compliance and communication risks
6. **Accessibility Review:** Check for inclusive design principles

**Special Considerations:**
    - Analyze images for embedded text, visual compliance, and brand consistency
    - Evaluate emojis for cultural appropriateness and professional context
    - Check for regulatory compliance specific to the message category
    - Assess multimodal accessibility and universal design principles

**Expected Analysis:"* Provide comprehensive analysis covering all aspects of the multimodal message with specific, actionable recommendations for improvement."""