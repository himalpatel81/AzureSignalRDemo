from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio
import logging
import time
from datetime import datetime, timezone
import uvicorn
import sys
import os

from auth.middleware import ApiKeyAuthenticationMiddleware
from models.message import HealthResponse, MMSAnalysisRequest, ResponseFormat
from contextlib import asynccontextmanager
from config import Config, config
from services.message_service import MessageService
from auth import (
    AuthenticationService,
    AuthenticationStatus,
    create_auth_middleware
)


# Add current directory to path for imports 
sys.path.insert(0, '.')

logging.basicConfig(
    level= logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

#Global variable to store the message service instance. 
message_service : Optional[MessageService] = None
auth_service: Optional[AuthenticationService] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Setup
    logger.info("Message Analyzer Service Starting up")
    global message_service

    try:
    
        config = Config()

        auth_service = AuthenticationService(config)

        await MessageService.initialize_shared_resources()

        message_service = MessageService(config)

        auth_status = auth_service.get_authentication_status()
    
    except Exception as e:
        logger.error(
            "Failed to initialize FastAPI application",
            error= str(e),
            error_type= type(e).__name__
        )

        
    yield  # App runs here
    
    # Teardown
    logger.info("Message Analyzer Service shutting down.")
    #Clean up shared service
    try:
    
        config = Config()
        MessageService.cleanup_shared_resources()

        message_service = None
        auth_service = None

    except Exception as e:
        logger.error(
            "Failed to initialize FastAPI application",
            error= str(e),
            error_type= type(e).__name__
        )

    
    

app = FastAPI(
    title = "Message Analyzer Open Service",
    description="High Performance Message Analysis Service",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

 #Setup auth middleware
# auth_middleware = create_auth_middleware(
#     app=app,
#     config = config,
#     excluded_paths = {
#         "/health"
#     }
# )
app.add_middleware(
    ApiKeyAuthenticationMiddleware,
    config= config,
    excluded_paths = {
        "/health"
    }
)

#Global Variables
service_start_time = time.time()
request_count=0
classification_cache= {}


#Health Check Endpoint
@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """
    Health check endpoint for monitoring service status
    """
    global service_start_time
    uptime = time.time() - service_start_time

    return HealthResponse(
        status="healthy",
        version="1.0.0",
        timestamp=datetime.now(timezone.utc).isoformat(),
        uptime_seconds= uptime
    )

#Analyze Endpoint
@app.post("/analyze", response_model=ResponseFormat, tags=["Analysis"])
async def analyze_message(request: MMSAnalysisRequest, background_tasks: BackgroundTasks):
    """
    Message Analysis Service Core Method
    """
    global request_count
    request_count += 1

    if message_service is None:
        raise HTTPException(
            status_code=503,
            detail="Message Service not initialized"
        )

    result = await message_service.process_mms_message(request)

    #Background Task for metric/logging
    #background_tasks.add_task(log_classification_metrics, request, result)
    return result

#Root endpoint
@app.get("/", tags=["Root"])
async def root():
    """
    Root endpoint with service information
    """
    
    return {
        "service" :"Message Analyzer Service",
        "version": "1.0.0",
        "status": "running",
        "endpoints":{
            "health":"/health",
            "analyze":"/analyze"
        }
    }

#Exception Handling
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.error(f"Unhandled exception {str(exc)}")
    return JSONResponse(
        status_code=500,
        content={
            "error":"Internal Server error",
            "message": "An unexpecated error occurred",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    )

if __name__ =="__main__":
    "Run the service"
    uvicorn.run(
        "service_main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )