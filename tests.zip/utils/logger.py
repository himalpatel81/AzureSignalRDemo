"""
Logging utilities for TextAnalyzer AI Analysis Engine
"""
import sys
import logging
import structlog
from typing import Optional
from pathlib import Path

def setup_logger(
    log_level: str = "INFO",
    log_file: Optional[str] = None,
    enable_json: bool = False
) -> structlog.stdlib.BoundLogger:
    """
    Setup structured logging for the application

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional log file path
        enable_json: Enable JSON formatted logging

    Returns:
        Configured structured logger
    """

    # configure standard library 10BEING
    logging.basicConfig(
        format="%(message)s",
        stream= sys.stdout,
        level=getattr(logging, log_level.upper())
    )
    
    #configure structlog processors
    processors = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="ISO"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder()
    ]
    if enable_json:
        processors.append(structlog.processors.J5ONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer(colors=True))

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        context_class=dict,
        cache_logger_on_first_use=True,
    )

    #Setup file logging if specified
    if log_file:
        try:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(getattr(logging, log_level.upper()))
            
            if enable_json:
                file_formatter - logging.Formatter('%(message)s')
            else:
                file_formatter = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                )

            file_handler.setFormatter(file_formatter)
            logging.getLogger().addHandler(file_handler)
        
        except Exception as e:
            print(f"Warning: Could not setup file logging: (e)", file=sys.stderr)
    
    #Create and return structured logger
    logger = structlog.get_logger("textanalyzer.ai")
    logger.info("Logger initialized", log_level=log_level, log_file=log_file)
    
    return logger

def get_logger(name: str = "textanalyzer,ai") -> structlog.stdlib.BoundLogger:
    """
    Get a named logger instance

    Args:
        name: Logger name

    Returns:
        Named structured logger
    """
    return structlog.get_logger(name)

class LoggingContext: 
    """Context manager for adding context to all log messages""" 
    
    def __init__(self, logger: structlog.stdlib.BoundLogger, *context): 
        self.logger = logger 
        self.context = context 
        self.bound_logger = None 
    
    def __enter__(self) -> structlog.stdlib.BoundLogger: 
        self.bound_logger - self.logger.bind(**self.context) 
        return self.bound_logger 
        
    def __exit__(self, exc_type, exc_val, exc_tb): 
        if exc_type: 
            self.bound_logger.error(
                "Exception occurred in logging context", 
                exc_type=exc_type.__name__,
                exc_msg=str(exc_val)
            )
             
    
def log_performance(logger: structlog.stdlib.BoundLogger): 
    """Decorator for logging function performance""" 
    def decorator(func): 
        def wrapper (*args, **kwargs): 
            import time 
            start_time = time.time()

            try:
                result = func(*args,**kwargs) 
                end_time = time.time()
            
                logger.Info(
                    f"Function{func.__name__} completed",
                    function=func.__name__,
                    duration_ms=round((end_time - start_time) * 1000, 2), 
                    success=True
                )
            
                return result
            except Exception as e: 
                end_time = time.time()
                logger.error(
                    f"Function {func.__name__} failed", 
                    function=func.__name__,
                    duration_ms=round((end_time - start_time) * 1000,2), 
                    error=str(e), 
                    success=False
                )

                raise
        return wrapper 
    return decorator

# def log_classification_request(
#         logger: structlog.stdlib.BoundLogger,
#         content_length: int,
#         guidelines_count: int, 
#         session_id: Optional[str] = None
# ):
#     """Log classification request details""" 
#     logger.info(
#         "Processing classification request", 
#         content_length=content_length, 
#         guidelines_count=guidelines_count, 
#         session_id=session_id
#     )

# def log_classification_result (
#     logger: structlog.stdlib.BoundLogger, 
#     classification: str, 
#     confidence: float, 
#     processing_time_ms: int,
#     violations_count: int,
#     has_suggestions: bool = False
# ):
#     """Log classification result details"""
#     logger.info(
#         "Classification completed",
#         classification-classification,
#         confidence=round(confidence, 3),
#         processing_time_ms=processing_time_ms,
#         violations_count=violations_count,
#         has_suggestions=has_suggestions
#     )

def log_openai_request(
    logger: structlog.stdlib.BoundLogger,
    model: str,
    prompt_length: int,
    request_type: str = "analysis"
):
    """Log OpenAI API request details"""
    logger.debug(
        "Making OpenAI API request",
        model=model,
        prompt_length=prompt_length,
        request_type=request_type
    )

def log_openai_response(
    logger: structlog.stdlib.BoundLogger,
    model: str,
    response_length: int,
    tokens_used: Optional[int] = None,
    cost_estimate: Optional[float] = None
):
    """Log OpenAI API response details"""
    logger.debug(
        """Received OpenAI API response""",
        model=model,
        response_length=response_length,
        tokens_used=tokens_used,
        cost_estimate=cost_estimate
    )


def log_error_with_context(
    logger: structlog.stdlib.BoundLogger,
    error: Exception,
    context: dict,
    operation: str="unknown"
):
    """Log error with additional context"""
    logger.error(
        f" Error in {operation}",
        error_type=type(error).__name__,
        error_message=str(error),
        operation=operation,
        **context
    )