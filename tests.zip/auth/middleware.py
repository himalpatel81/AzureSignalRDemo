import time
import structlog
from typing import Callable, Optional, Set
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from auth.models import ApiKeyInvalidError, ApiKeyMissingError, AuthenticationDisabledError
from auth.service import AuthenticationService
from config import Config
from utils.logger import log_error_with_context

class ApiKeyAuthenticationMiddleware(BaseHTTPMiddleware):
    """Fast API Auth"""

    def __init__(self, 
                 app, 
                 config: Config,
                 excluded_paths: Optional[Set[str]] = None,
                 excluded_methods: Optional[Set[str]] = None):
        super().__init__(app)
        self.config = config
        self.logger = structlog.get_logger('auth_middleware')
        self.auth_service = AuthenticationService(config)

        self.excluded_paths = excluded_paths or {
            "/health"
        }

        self.excluded_methods = excluded_methods or {"OPTIONS"}
    
    async def dispatch(
        self, 
        request: Request,
        call_next: Callable
    ) -> Response:
        start_time = time.time()

        if self._should_exclude_request(request):
            self.logger.debug(
                "Request excluded from authentication",
                path = request.url.path,
                method = request.method
            )
            return await call_next(request)

        try:
            auth_result = self.auth_service.authenticate_request(request)
            if not auth_result.success:
                return self._create_error_response(
                    status_code=401,
                    message= "Authentication Failed",
                    detail={"error_tuype":"authentication_failed"},
                    request=request,
                    processing_time_ms=11
                )
            request.state.authenticated= True
            request.state.auth_result = auth_result

            response = await call_next(request)

            if hasattr(response, 'headers'):
                response.headers['X-Authenticated'] = "true"
                # TODOresponse.headers['X-Auth-Timestamp'] = auth_result.timestamp.isoformat()
            return response
        
        except ApiKeyMissingError as e: 
            self.logger.warning(
                "Authentication failed: missing API key", 
                path=request.url.path, 
                method=request.method, 
                client_ip=self._get_client_ip(request), 
                required_header=e.detail.get("required_header")
            )
            
            return self._create_error_response(
                status_code=e.status_code, 
                message=e.message, 
                detail=e.detail, 
                request=request, 
                processing_time_ms=int((time.time() - start_time) * 1000)
            )
        
        except ApiKeyInvalidError as e:
            self.logger.warning(
                "Authentication failed: invalid API key", 
                path=request.url.path, 
                method=request.method,
                client_ip=self._get_client_ip(request), 
                provided_key_preview=e.detail.get("provided_key", "")[:8] + "..." if e.detail.get("provided_key") else None
            )

            return self._create_error_response(
                status_code=e.status_code, 
                message=e.message,
                detail=e.detail if self.config.authentication_error_detail else {"error_type": "invalid api key"}, 
                request=request,
                processing_time_ms=int((time.time() - start_time) * 1000)
            )
        except AuthenticationDisabledError as e:
            self.logger.error(
                "Authentication disabled but required", 
                path=request.url.path, 
                method=request.method
            )
            
            return self._create_error_response(
                status_code=e.status_code, 
                message=e.message, 
                detail=e.detail, 
                request=request, 
                processing_time_ms=int((time.time() - start_time) * 1000)
            )
            I
        except Exception as e: 
            # Handle unexpected errors 
            log_error_with_context(
                self.logger,
                e,
                {
                    "path": request.url.path, 
                    "method": request.method, 
                    "client_ip": self._get_client_ip(request)
                },
                'auth_middleware_dispatch'
            )
            return self._create_error_response(
                status_code=500,
                message =  "Internal authentication error",
                detail={"error_type": "Internal_auth_errors"},
                request=request,
                processing_time_ms= int((time.time() - start_time) *1000)
            )
    def _should_exclude_request(self, request: Request) -> bool:
        """
        check if request should be excluded from authentication
        Args:
        request: HTTP request to check
        Returns:
        True If request should be excluded from authentication
        """
        
        # skip if authentication is disabled
        if not self.config.enable_authentication:
            return True
        
        # check excluded methods
        if request.method in self. excluded_methods:
            return True
        
        #check excluded paths
        path = request.url.path
        if path in self.excluded_paths:
            return True
        
        # check for path patterns could be extended with regex matching
        excluded_prefixes = ["/docs", "/redoc","/openapi","/static"]
        for prefix in excluded_prefixes:
            if path.startswith(prefix):
                return True
        return False


    def _get_client_ip(self, request: Request) -> Optional[str]: 
        """Get client IP address from equest""" 
        # Check for forwarded headers (common in load balancers) 
        forwarded_for = request.headers.get ("X-Forwarded-For") 
        if forwarded_for: 
            return forwarded_for.split(",")[0].strip()

        # Check for real IP header
        real_ip = request.headers.get("X-Real-IP") 
        if real_ip:
            return real_ip
        
        # Fall back to client host 
        return request.client.host if request.client else None

    def _create_error_response(
        self,
        status_code:int,
        message:str,
        detail: dict,
        request: Request,
        processing_time_ms:int
    ) -> JSONResponse:
        """
        JSON
        """
        error_response={
            "success":False,
            "error": message
        }

        if status_code == 401:
            error_response["authentication_required"] = True
            error_response["required_header"] = self.config.api_key_header

            if not self.config.authentication_error_detail:
                error_response["detail"] = {"error_type": detail.get("error_type", "authentication_error")}
        headers={
            "WWW-Authenticate":f'ApiKey realm="API", charset="UTF-8"',
            "X-Authentication-Required":"true",
            "X-Required-Header":self.config.api_key_header       
        }

        return JSONResponse(
             status_code= status_code,
             content= error_response,
             headers= headers
        )

def create_auth_middleware(
    app,
    config: Config,
    excluded_paths : Optional[Set[str]] = None,
    excluded_methods : Optional[Set[str]] = None
) -> ApiKeyAuthenticationMiddleware:
        """
        Factory
        """
        return ApiKeyAuthenticationMiddleware(
        app= app,
        config = config,
        excluded_paths=  excluded_paths,
        excluded_methods= excluded_methods
        )
    
         
            
