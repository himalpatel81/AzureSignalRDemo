#!/usr/bin/env python3
"""
TextAnalyzer AI Engine - Main Entry Point 
Standalone executable for SMS message Analysis with OpenAI integration
"""
import sys 
import json 
import asyncio 
import traceback 
from typing import Dict, Any

from models.message import MMSAnalysisRequest
from services.message_service import MessageService
from utils.logger import log_error_with_context, setup_logger
from config import config

# Add current directory to path for imports 
sys.path.insert(0, '.')

async def main() -> int:
    """Main entry point for the Analysis engine

    Returns:
        Exit code (0 for success, 1 for error)
    """
    logger  = None
    try:
        # Setup logging 
        logger = setup_logger( 
            log_level=config.log_level,
            log_file=config.log_file, 
            enable_json=False
        )
        logger.info("TextAnalyzer AI Analysis Engine starting")
        # Read plain text input from stdin 
        logger.debug("Reading input from stdin") 
        #input_data = sys.stdin.read() 
        input_data = '{    "content":{        "text":"Vote for Maria Rodriguez for Congress! She will fight for healthcare reform and create more jobs. Paid for by Rodriguez Campaign Committee.",        "images":[            {                "image_data":"iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAIAAADrOSKFAAACtUlEQVR4nO3a0W6bMABAUZjy/7/MHlJFDBLHS7peaTlHVUVaYozEraHtum3bAnR+1ROATydCiIkQYiKEmAghJkKIiRBiIoSYCCF2GX97XX9mGvCfG/xnmpUQYiKE2JPb0Rv/5g0vmHmgsxJCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFC7PLOm9d1WZZl2742BtsD23Z/2PM+g5HPgwxG249wGGrmXO6e12ACMPadK+H+yl6WP7ZvG/uX14+745z3OYx8GPZR7Xfn8Ohwh5e3o5zPa+YsYNJbEe4vvr+6vpdlWdfn6+TMPpMOqby8lJ3H+a4Z8rHeuh29eu0qnLnoZ/Y5rHXzR79N+7px+7xf5Q6ntr8jnZ8hjJW/mPmWZWR8Ozp/rJd/KFgMedO7EZ6f9JbT89vVfsFZhtnc3ecw8n6fQYeP3nU+1t2vPHrynDkLmLRuwyXgfAMGzJspyN8JISZCiIkQYiKEmAghJkKIiRBiIoSYCCEmQoiJEGIihJgIISZCiIkQYiKEmAghJkKIiRBiIoSYCCEmQoiJEGIihJgIISZCiIkQYiKEmAghJkKIiRBiIoSYCCEmQoiJEGIihJgIISZCiIkQYiKEmAghJkKIiRBiIoSYCCEmQoiJEGIihJgIISZCiIkQYiKEmAghJkKIiRBiIoSYCCEmQoiJEGIihJgIISZCiIkQYiKEmAghJkKIiRBiIoTYZXK/df2n04DPZSWEmAgh9uR2dNt+ZhrwuayEEBMhxEQIMRFCTIQQEyHERAgxEULsN6tknyG0azj1AAAAAElFTkSuQmCC",                "mime_type":"image/png",                "file_name":"campaign.png" }        ],        "emojis":[            {                "emoji":"🗳️",                "unicode_code":"U+1F5F3",                "description":"ballot box withballot"            },            {                "emoji":"us",                "unicode_code":"U+1F1FA U+1F1F8",                "description":"flag of United States"            }        ]    },    "category":"Political",    "session_id":"mms-1"}'
        #input_data = "Vote for candidate Smith in the upcoming election. She will fight for lower taxes and better schools for our community.".strip()
        
        if not input_data.strip(): 
            raise ValueError ("No input data provided via stdin")
        message_content = input_data.strip()

        is_mms = False
        request = None
        #toto try:
        json_data = json.loads(message_content)
        if 'content' in json_data and isinstance(json_data['content'], dict):
            #This looks like MMS Format
            request = MMSAnalysisRequest.from_dict(json_data)
            is_mms = True
            #todolog
        # else:
        #     request = Class
        await MessageService.initialize_shared_resources()
        message_service = MessageService(config)
        
        # if config.openai_api_key: 
        #     logger.debug("Testing OpenAI connection") 
        #     connection_ok = await message_service.openai_service.test_connection() 
        #     if not connection_ok: 
        #         logger.warning("OpenAI connection test failed, proceeding anyway")
        
        if is_mms:
            #todolog
            result = await message_service.process_mms_message(request)
        
        output_json = result.model_dump_json() 
        
        print(output_json, flush=True)
        
        return 0
    except KeyboardInterrupt: 
        if logger: 
            logger.info("Analysis interrupted by user") 
        return 1
    except Exception as e:
        # Create error response
        logger.debug("Testing OpenAI connection")
        
        
        # Log error
        if logger:
            log_error_with_context(
                logger,
                e,
                {
                "traceback": traceback.format_exc(), 
                "input_length": len(input_data) if 'input_data' in locals() else 0
                },
                "main_analysis"
            )
        else:
            print(f"ERROR: (str(e))", file=sys.stderr)
        
        return 1

if __name__ == '__main__':
    # Validate environment before starting 
    # if not validate_environment(): 
    #     sys.exit(1)
    
    # Run main analysis process 
    try:
        exit_code = asyncio.run(main()) 
        sys.exit(exit_code) 
    except Exception as e: 
        print(f"FATAL ERROR: {str(e)}", file=sys.stderr) 
        sys.exit(1)