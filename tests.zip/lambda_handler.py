"""
AWS Lambda Handler
"""

import os
import sys
import asyncio
import json
from typing import Dict, Any
import structlog
from mangum import Mangum

sys.path.insert(0,os.path.dirname(__file__))


from service_main import app 
from services.message_service import MessageService

def is_lambda_environment() -> bool: 
    """Detect if running in AWS Lambda environment""" 
    return bool(os.environ.get('AWS_LAMBDA_FUNCTION_NAME'))

def configure_lambda_logging():
    """Configure structured logging for AWS Lambda (Cloudwatch)""" 
    if is_lambda_environment(): 
        # Lambda-specific logging configuration 
            structlog.configure(
                processors=[
                    structlog.contextvars.merge_contextvars, 
                    structlog.processors.add_log_level, 
                    structlog.processors.TimeStamper(fmt="ISO"), 
                    structlog.processors.JSONRenderer()
                ],
                wrapper_class=structlog.make_filtering_bound_logger(20), #INFO level 
                logger_factory=structlog.WriteLoggerFactory(), 
                context_class=dict, 
                cache_logger_on_first_use=True,
) 
    # For local development keep existing logging configuration

class LambdaFastAPIHandler:
    """
    Lambda-compatible FastAPI handler with initialization management 
    Provides seamless operation in both local and Lambda environments
    """
    def __init__ (self, fastapi_app): 
        self0app= fastapi_app 
        self.logger = structlog.get_logger ("lambda_handler") 
        self._initialized = False 
        self._initialization_lock = asyncio.Lock()

        # Configure logging for Lambda environment 
        configure_lambda_logging()
        
        # Create Mangum adapter (only used in Lambda) 
        if is_lambda_environment(): 
            self.mangum = Mangum(
                fastapi_app,
                lifespan="off", # Disable FastAPI lifespan in Lambda 
                api_gateway_base_path=None, # Auto-detect from event 
                text_mime_types=[
                    "application/json"
                    "application/javascript"
                    "application/xml",
                    "application/vnd.api+json"
                ]
            )
            self.logger.info("Lambda handler initialized with Mangum adapter") 
        else:
            self.mangum= None
            self.logger.info("Handler initialized for local development mode")

    async def initialize_shared_resources(self):
        """Initialize shared resources for Lambda cold starts""" 
        async with self._initialization_lock:
            if not self._initialized and is_lambda_environment(): 
                try:
                    self.logger.info("Initializing shared resources for Lambda cold start")

                    # Initialize the same shared resources as local mode 
                    await MessageService.initialize_shared_resources()
                    self._initialized = True 
                    self.logger.info("Lambda cold start initialization completed successfully") 
                except Exception as e:
                    self.logger.error(
                        "Failed to initialize shared resources in Lambda",
                        error=str(e),
                        error_type=type(e).__name__
                    )
                    raise

    async def __call__(self, event: Dict[str, Any], context: Any) -> Dict[str, Any]:
        """
        AWS Lambda entry point
        Handles both API Gateway and direct invocation events
        """
        if not is_lambda_environment(): 
            raise RuntimeError("Lambda handler called outside Lambda environment")
        try: 
            # Log the incoming event (for debugging) 
            self.logger .debug(
                "Lambda invocation started",
                request_id=context.aws_request_id if context else "unknown", 
                function_name=context.function_name if context else "unknown",
                remaining_time_ms=0
                #remaining_time_ms=context.get_remaining_time_in_millis() if context else 0
            )

            # Initialize shared resources on first invocation (cold start) 
            if not self._initialized: 
                await self.initialize_shared_resources()

            # Process the request through Mangum 
            response = await self.mangum(event, context)
            self.logger.info(
                "Lambda invocation completed successfully",
                request_id=context.aws_request_id if context else "unknown", 
                status_code=response.get("statusCode", "unknOwn")
            )
        
            return response
        except Exception as e:
            # Log the error with full context
            self.logger.error(
                "Lambda invocation failed", 
                error=str(e),
                error_type=type(e).__name__,
                request_id=context.aws_request_id if context else "unknown", 
                event_type=event.get("version", "unknown") if isinstance(event, dict) else "unknown"
            )
            # Return error response in API Gateway format "
            return{
                "statusCode": 500,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
                },
                "body": json.dumps({
                    "success": False,
                    "error": "Internal server error", 
                    "message": str(e),
                    "request_id": context.aws_request_id if context else "unknown"
                })
            }

# Create the handler instance
lambda_fastapi_handler = LambdaFastAPIHandler(app)
def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main AWS Lambda handler function 
    This is the entry point that AWS Lambda will call
    """
    # Handle the event in async context
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    try:
        return loop.run_until_complete(lambda_fastapi_handler(event, context))
    finally:
        loop.close()

# For local testing of the Lambda handler
if __name__ ==  "__main__":
    print("Lambda handler module loaded successfully")
    print(f"Running in Lambda environment: fis_lambda_environment()?")

    if not is_lambda_environment():
        print("For local FastAPI development, run: python optimized_ pythonservice.py")
        print("For Lambda testing, use: aws lambda invoke --function-name your-function")
