import unittest
from unittest.mock import MagicMock, patch, AsyncMock
from models.message import MMSAnalysisRequest, MMSContent, ResponseFormat
from services.message_service import MessageService
from config import Config
import asyncio

class TestMessageService(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.config = MagicMock(spec=Config)
        self.service = MessageService(self.config)
        self.service.logger = MagicMock()
        self.service.openai_service = MagicMock()
        self.service.guideline_service = MagicMock()

        # Mock shared resources
        MessageService._shared_guideline_service = MagicMock()
        
        # Sample request data
        self.valid_request = MMSAnalysisRequest(
            content=MMSContent(text="Test message"),
            category="political"
        )
        
        # Sample response
        self.valid_response = ResponseFormat(
            success=True,
            suggested_message="Optimized message",
            justification="Improved compliance",
            impact_score=0.9
        )

    @patch('services.message_service.MessageService.guideline_service', new_callable=MagicMock)
    @patch('services.message_service.OpenAIService.analyze_mms_content', new_callable=AsyncMock)
    async def test_process_mms_message_success(self, mock_analyze, mock_guideline_service):
        """Test successful message processing"""
        # Setup
        mock_analyze.return_value = self.valid_response
        mock_guideline_service.get_guidelines_for_category.return_value = []
        
        # Execute
        response = await self.service.process_mms_message(self.valid_request)
        
        # Verify
        self.assertTrue(response.success)
        self.assertEqual(response.suggested_message, "Optimized message")
        self.assertEqual(response.justification, "Improved compliance")
        mock_analyze.assert_awaited_once()
        self.service.logger.info.assert_called()
        self.service.logger.error.assert_not_called()

    @patch('services.message_service.OpenAIService.analyze_mms_content', new_callable=AsyncMock)
    async def test_process_mms_message_exception_handling(self, mock_analyze):
        """Test exception handling during message processing"""
        # Setup
        mock_analyze.side_effect = Exception("Test error")
        
        # Execute
        response = await self.service.process_mms_message(self.valid_request)
        
        # Verify
        self.assertFalse(response.success)
        self.assertEqual(response.error_message, "Test error")
        self.assertEqual(response.suggested_message, "")
        self.service.logger.error.assert_called()

    @patch('services.message_service.OpenAIService.analyze_mms_content', new_callable=AsyncMock)
    async def test_process_mms_message_with_images(self, mock_analyze):
        """Test message processing with images"""
        # Setup
        request = MMSAnalysisRequest(
            content=MMSContent(
                text="Test with images",
                images=[{"image_data": "base64data", "mime_type": "image/png"}]
            ),
            category="general"
        )
        mock_analyze.return_value = self.valid_response
        
        # Execute
        response = await self.service.process_mms_message(request)
        
        # Verify
        self.assertTrue(response.success)
        mock_analyze.assert_awaited_once()
        self.service.logger.info.assert_called_with(
            "Starting MMS message processing"
        )

    @patch('services.message_service.OpenAIService.analyze_mms_content', new_callable=AsyncMock)
    async def test_process_mms_message_with_emojis(self, mock_analyze):
        """Test message processing with emojis"""
        # Setup
        request = MMSAnalysisRequest(
            content=MMSContent(
                text="Test with emojis 😊",
                emojis=[{"emoji": "😊", "unicode_code": "U+1F60A"}]
            ),
            category="notforprofit"
        )
        mock_analyze.return_value = self.valid_response
        
        # Execute
        response = await self.service.process_mms_message(request)
        
        # Verify
        self.assertTrue(response.success)
        mock_analyze.assert_awaited_once()
        self.service.logger.info.assert_called_with(
            "MMS processing request",
            category="notforprofit",
            text_length=len("Test with emojis 😊"),
            image_count=0,
            emoji_count=1,
            session_id=request.session_id
        )

if __name__ == '__main__':
    unittest.main()