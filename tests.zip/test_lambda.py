#!/usr/bin/env python3 ann
"""
Test script for validating Lambda deployment of TextAnalyzer FastAPI service 
Tests both local Lambda handler and deployed Lambda function
"""
import json 
import sys 
import os 
import requests 
import argparse 
from pathlib import Path 
from typing import Dict, Any, Optional
import traceback

class LambdaTester:
    """Test suite for Lambda deployment validation""" 
    def __init__(self, api_gateway_url: Optional[str] = None, api_key: Optional[str] = None): 
        self.api_gateway_url = api_gateway_url.rstrip("/") if api_gateway_url else None 
        self.api_key = api_key
        self.ai_dir = Path(__file__).parent
        print(f"setting ai path {self.ai_dir}")
        # Test payloads
        self.test_messages = {
            "political":{
                "content": "Vote for John Smith in the upcoming election! Authorized by Smith Campaign Committee.",
                 "expected classification": "Political"
            },
            "nonprofit":{
                "content": "Help us fight hunger in our community. Donate to Food Bank Foundation, a 501(c)(3) nonprofit.", 
                "expected_classification": "NotForProfit"
            },
            "general":{
                "content": "Your appointment is confirmed for tomorrow at 2 PM. Contact us at info@clinic.com if you need to reschedule.",
                "expected _classification": "General"
            }
        }

    def test_local_lambda_handler(self) -> bool: 
        """Test the Lambda handler locally without AWS""" 
        print(" Testing Lambda handler locally...")
        try:
            # Add AI directory to path 
            sys.path.insert(0, str(self.ai_dir))
            
            # Set Lambda environment variable 
            os.environ["AWS_LAMBDA_FUNCTION_NAME"] = 'test-function'
                
            # Import handler 
            from lambda_handler import handler
            
            # Create mock context
            class MockContext:
                aws_request_id = "test-request-123" 
                function_name = "test-function" 
                function_version = "$LATEST" 
                invoked_function_arn = "arn:aws:lambda:us-east-1:123456789012:function:test-function" 
                memory_limit_in_mb = "1024" 
                remaining_time_in_millis = lambda self: 30000

            context = MockContext()
        
            # Test health endpoint
            health_event = {
                "httpMethod": "GET",
                "path": "/health",
                "headers": {"Content-Type": "application/json"},
                "multiValueHeaders": {},
                "queryStringParameters": None,
                "multiValueQueryStringParameters": None, 
                "body": None,
                "isBase64Encoded": False,
                "pathParameters": None,
                "stageVariables": None,
                "requestContext": {
                    "requestTime": "09/Apr/2015:12:34:56 +0000",
                    "requestId": "c6af9ac6-7b61-11e6-9a41-93e8deadbeef",
                    "httpMethod": "GET", 
                    "path": "/health", 
                    "stage": "test",
                    "identity": {"sourceIp": "127.0.0.1"}, 
                    "protocol": "HTTP/1.1"
                }
            }
    
            print(" Testing health endpoint...") 
            response = handler (health_event, context)
            if response["statusCode"] == 200:
                print(" Y Health endpoint test passed")
                body = json.loads(response["body"])
                print(f" Service status: {body.get("status", 'unknown')}")
                print(f"Version: {body.get('version', "unknown")}")
            else:
                print(f" X Health endpoint failed: (response)") 
                return False
            
            print("¥ Local Lambda handler test completed successfully") 
            return True
        
        except Exception as e:
            print(f"X Local Lambda handler test failed: {e} - {traceback.format_exc()}") 
            return False
        finally:
            # Clean up environment
            if 'AWS_LAMBDA_FUNCTION_NAME' in os.environ:
                del os.environ['AWS_LAMBDA_FUNCTION_NAME']

    def test_deployed_lambda (self) -> bool: 
        """Test the deployed Lambda function Via APT Catersymon """
        if not self.api_gateway_url: 
            print("No API Gateway URL")
            return True
        
        print(f"testing  Deployed lampta at {self.api_gateway_url}")

        try:
            #Test health endpoint
            response = requests.get(
                f"{self.api_gateway_url}/health",
                timeout = 30
            )
        
            if response.status_code == 200: 
                health_data = response.json() 
                print(" Health endpoint test passed" )
                print(f" Service Status: {health_data.get('status','unknown')}")
                print(f" Authentication enabled {health_data.get('details',{}).get('authentication_enabled','unknown')}")
                print(f" Guidelines enabled {health_data.get('details',{}).get('shared_resources_loaded','unknown')}")
            else:
                print(f" Health Endpoint failed {response.status_code} - {response.text}")

            if self.api_key:
                print("Testing Auth")
                auth_response = requests.get(
                    f"{self.api_gateway_url}/auth/status",
                    headers={"X-API-Key": self.api_key},
                    timeout= 30
                )

                if auth_response.status_code == 200:
                    auth_data = auth_response.json()
                    print(f"Auth enabled {auth_data.get('authentication_enabled','unown')}")
                    print(f" Valid Keys {auth_data.get('valid_keys_count','unknown')}")
                else:
                    print(f"Auth failed {auth_response.status_code}")
            
            print(" M Deployed Lambda test completed successfully") 
            return True

            #auth_data = auth_response.json() print(" M Authentication test passed") print(f" Auth enabled: (auth_data.get("authentication_enabled', 'unknown')"") print(f" Valid keys: (auth_data.get("valid_keys_count", ' unknown')]") else: p rint(f" X Authentication test failed: (auth_response. status_code)")

        except requests.RequestException as e: 
            print(f"X Deployed Lambda test failed: {e})") 
            return False
        
    def test_classification_endpoints(self) -> bool:
        """Test the classification functionality""" 
        if not self.api_gateway_url or not self.api_key: 
            print("A API Gateway URL or API key not provided, skipping classification tests") 
            return True

        print("G Testing classification endpoints...")

        headers ={
            "Content-Type": "application/json", 
            "X-API-Key": self.api_key
        }
        
        all_tests_passed = True
        for test_name, test_data in self.test_messages.items(): 
            print(f" E Testing (test_name) classification...")
            
            payload = {
                "content": test_data["content"], 
                "session_id": f"test-(test_name)-123"
            }

            try:
                response =requests.post(
                    f"{self.api_gateway_url}/classify", 
                    json=payload, 
                    headers=headers, 
                    timeout=30
                )
                if response.status_code == 200:
                    result = response.json()
                    classification = result.get ("classification", "unknown") 
                    confidence = result.get("confidence_score", 0) 
                    processing_time = result.get ("processing_time_ms", 0)

                    print(f"{test_name.title()} test passed") 
                    print(f" Classification: {classification}")
                    print(f" Confidence: {confidence:.1%}")
                    print(f" Processing time: {processing_time}ms")
                
                    # Check if classification matches 
                    expected = test_data["expected_classification"]
                    if classification == expected: 
                        print(f" Expected classification matched: {expected}")
                    else:
                        print(f" A Classification mismatch: expected {expected}, got {classification}")
                else:
                    print(f" X {test_name.title()} test failed: {response.status_code} - {response.text}") 
                    all_tests_passed = False
            
            except requests.RequestException as e: 
                print(f" X {test_name.title()} test error: {e})") 
                all_tests_passed - False

        if all_tests_passed:
            print(" ' All classification tests completed successfully") 
        else:
            print("X Some classification tests failed")
        
        return all_tests_passed

    def test_mms_endpoint(self) -> bool: 
        """Test the MMS classification endpoint""" 
        if not self.api_gateway_url or not self.api_key: 
            print("A API Gateway URL or API key not provided, skipping MMS test") 
            return True

        print(" E Testing MMS classification endpoint...")
        headers ={
            "Content-Type": "application/json", 
            "X-API-Key": self.api_key
        }

        # Simple MMS test payload
        mms_payload = {
            "classification": "General", 
            "content":{
                "text": "Check out this great offer! Valid until tomorrow.",
                "images": [], 
                "emojis": [{
                    "emoji":" ",
                    "unicode_code": "U+1F389",
                    "description": "Party popper"
                    }
                ]
            },
            "session_id": "test-mms-123"
        }
        try:
            response= requests.post(
                f"{self.api_gateway_url}/classify-mms", 
                json=mms_payload, 
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                print("   MMS classification test passed")
                print(f"Classification: {result.get("classification", 'unknown')}")
                print(f"Confidence: {result.get('confidence_score', 0):.1%}")
                print(f"Processing time: {result.get("processing time ms", 0)}ms")
                print(f"Violations found: {len(result.get('violations', []))}")
                return True
            else:
                print(f" X MMS test failed: {response.status_code} - {response.text}") 
                return False
            
        except requests.RequestException as e: 
            print(f" X MMS test error: {e})") 
            return False

    def run_all_tests(self) -> bool: 
        """Run complete test suite"""
        print("# Starting Lambda deploymenË test suite...") 
        print("-" * 50)
        
        tests_passed= []

        # Test 1: Local Lambda handler 
        tests_passed.append(self.test_local_lambda_handler()) 
        print()
        # Test 2: Deployed Lambda (if URL provided) 
        tests_passed.append(self.test_deployed_lambda()) 
        print()
        # Test 3: Classification endpoints (if URL and API key provided) 
        tests_passed.append(self.test_classification_endpoints()) 
        print()

        print("=" * 50)
        total_tests = len(tests_passed) 
        passed_tests = sum(tests_passed)

        if all(tests_passed):
            print(" All tests passed successfully!")
            print(f" Tests completed: {passed_tests}/{total_tests}") 
            return True
        else:
            print("X Some tests failed")
            print(f" Tests passed: {passed_tests}/{total_tests}") 
            return False
    
def main():
        parser = argparse.ArgumentParser(description="Test Lambda deployment of TextAnalyzer service") 
        parser.add_argument("--url", help="API Gateway URL for deployed Lambda") 
        parser.add_argument("--api-key", help="API key for authentication") 
        parser.add_argument("--local-only", action="store_true", help="Run only local tests")

        args = parser.parse_args()
        # if args.local_only:
        tester = LambdaTester()
        success = tester.test_local_lambda_handler()
        # else: 
        #     tester= LambdaTester(args.url, args.api_key) 
        #     success = tester.run_all_tests()
        
        sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()

