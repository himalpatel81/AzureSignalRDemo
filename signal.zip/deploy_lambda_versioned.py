import tempfile
#!/usr/bin/env python3
"""
AWS Lambda Deployment Script for TextAnalyzer FastAPI Service 
Handles initial deployment, updates, and configuration management
"""
import os 
import sys 
import json 
import zipfile 
import shutil 
import subprocess 
import argparse 
import boto3 
import time 
from pathlib import Path 
from typing import Dict, List, Optional, Any 
from botocore.exceptions import ClientError

class LambdaDeploymentError(Exception): 
    """Custom exception for Lambda deployment errors""" 
    pass
class LambdaDeployer: 
    """AWS Lambda deployment and management class"""
    def __init__(self, function_name: str, region: str = "us-east-1"): 
        self.function_name = function_name 
        self.region = region 
        self.lambda_client = boto3.client('lambda', region_name=region) 
        self.iam_client = boto3.client('iam', region_name=region) 
        self.apigateway_client = boto3.client('apigatewayv2', region_name=region)
        self.dry_run = False

        #Deployment configuration 
        self.deployment_config = {
            "runtime": "python3.11", 
            "timeout": 30, 
            "memory_size": 512, 
            "architecture": "x86_64", 
            "environment_variables": {}, 
            "layers": []
        } 
        # Project paths
        self.project_root = Path(__file__).parent 
        self.deployment_package = Path(tempfile.mkdtemp()) / f"{self.function_name}-20250731_004858-deployment.zip"

    def load_environment_config(self, env_file: Optional[str] = None) -> Dict[str, str]: 
        """Load environment variables from .env file""" 
        env_vars = {} 
        env_file_path = env_file or self.project_root / ".env"

        if Path(env_file_path).exists(): 
            with open(env_file_path, 'r') as f: 
                for line in f: 
                    line = line.strip() 
                    if line and not line.startswith('#'): 
                        if '=' in line: 
                            key, value = line.split('=', 1) 
                            env_vars[key.strip()] = value.strip()

        # Add Lambda-specific environment variables 
        env_vars.update({
            "AWS_LAMBDA_FUNCTION_NAME": self.function_name, 
            "LAMBDA_ENVIRONMENT": "true", 
            "PYTHONPATH": "/var/task"
        })

        return env_vars
    
    def create_deployment_package(self, exclude_patterns: Optional[List[str]] = None) -> str: 
        """Create deployment package with dependencies""" 
        print(f" ○ Creating deployment package for {self.function_name}...")
        
        if self.dry_run:
            print(f" [DRY RUN] Would create deployment package at {self.deployment_package}")
            return str(self.deployment_package)
            
        # Clean and create build directory 
        if self.build_dir.exists(): 
            shutil.rmtree(self.build_dir) 
        self.build_dir.mkdir(parents=True, exist_ok=True)

        # Temporary directory for package contents 
        package_dir = self.build_dir / "package" 
        package_dir.mkdir(exist_ok=True)

        # Install dependencies 
        self._install_dependencies(package_dir) 
        
        # Copy application code
        self._copy_application_code(package_dir, exclude_patterns or [])
    
        # Create ZIP package 
        self._create_zip_package(package_dir)

        return str(self.deployment_package)

    def _install_dependencies(self, target_dir: Path): 
        """Install Python dependencies to target directory""": 
        print("' Installing Python dependencies...")
        requirements_file = self.project_root / "lambda_requirements.txt" 
        if not requirements_file.exists (): 
            requirements_file = self.project_root / "requirements.txt"
        
        if requirements_file.exists():
            if self.dry_run:
                print(f" [DRY RUN] Would install dependencies from {requirements_file}")
                return

            cmd=[
                sys.executable, "-m", "pip", "install", 
                "-r", str(requirements_file), "-t", str(target_dir), 
                "--no-deps", "--platform", "linux_x86_64", 
                "--implementation", "cp", "--python-version", "3.11", 
                "--only-binary=:all:", "--upgrade"
            ]
    
            try:
                result = subprocess.run(cmd, check=True, capture_output=True, text=True) 
                print(" Dependencies installed successfully") 
            except subprocess.CalledProcessError as e: 
                print(f" X Error installing dependencies: {e.stderr}") 
                raise LambdaDeploymentError(f"Failed to install dependencies: {e.stderr}")
        else:
            print("A No requirements file found, skipping dependency installation")

    def _copy_application_code(self, target_dir: Path, exclude_patterns: List[str]): 
        """Copy application code to package directory""" 
        print("_ Copying application code...")
        
        # Default exclusions
        default_excludes =[ 
            "pycache__", "*.pyc", ".git", ".gitignore", ".env*",
            "tests", "test_*", "*_test.py", "*.md", ".vscode", 
            "build", "dist", "*.egg-info", ".pytest_cache", 
            "deployment", "deploy_*", "*.log" 
        ] 
        exclude_patterns.extend(default_excludes)
    
        # Copy files
        for item in self.project_root.iterdir(): 
            if item.is_file():
                if not self._should_exclude(item.name, exclude_patterns):
                    shutil.copy2(item, target_dir / item.name)
            elif item.is_dir(): 
                if not self._should_exclude(item.name, exclude_patterns): 
                    shutil.copytree(item, target_dir / item.name, ignore=shutil.ignore_patterns(*exclude_patterns))

        print(" Application code copied successfully")

    def _should_exclude(self, name: str, exclude_patterns: List[str]) -> bool:
         """Check if file/directory should be excluded"""   
         import fnmatch 
         return any(fnmatch.fnmatch(name, pattern) for pattern in exclude_patterns)
    
    def _create_zip_package(self, package_dir: Path): 
        """Create ZIP package from directory""" 
        print("G Creating ZIP package...")

        if self.dry_run:
            print(f" [DRY RUN] Would zip contents of {package_dir} to {self.deployment_package}")
            return

        with zipfile.ZipFile(self.deployment_package, 'w', zipfile.ZIP_DEFLATED) as zipf: 
            for root, dirs, files in os.walk(package_dir):
                for file in files: 
                    file_path = Path(root) / file 
                    arcname = file_path.relative_to(package_dir) 
                    zipf.write(file_path, arcname)

        # Check package size 
        package_size = self.deployment_package.stat().st_size / (1024 * 1024) # MB 
        print(f" Package size: {package_size:.2f} MB")

        if package_size > 50: 
            print("A Warning: Package size exceeds 50MB - consider using Lambda layers")

    def create_lambda_role(self, role_name: Optional[str] = None) -> str: 
        """Create IAM role for Lambda function""" 
        role_name = role_name or f"{self.function_name}-role"
        print(f"& Creating IAM role: {role_name}")

        if self.dry_run:
            print(f" [DRY RUN] Would create or use IAM role: {role_name}")
            return f"arn:aws:iam::123456789012:role/{role_name}"

        # Trust policy for Lambda 
        trust_policy = {
            "Version": "2012-10-17", 
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "lambda.amazonaws.com"}, 
                    "Action": "sts:AssumeRole"
                }
            ]
        }

        try: 
            # Try to get existing role 
            response = self.iam_client.get_role(RoleName=role_name) 
            role_arn = response['Role']['Arn'] 
            print(f" Using existing role: {role_arn}") 
            return role_arn 
        except ClientError as e:
            if e.response['Error']['Code'] != 'NoSuchEntity':
                raise


        # Create new role
        try:
            response = self.iam_client.create_role(
                RoleName=role_name, 
                AssumeRolePolicyDocument=json.dumps(trust_policy), 
                Description=f"IAM role for Lambda function {self.function_name}"
            )
            role_arn = response['Role']['Arn']

            # Attach basic Lambda execution policy 
            self.iam_client.attach_role_policy(
                RoleName=role_name, 
                PolicyArn='arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'
            )
            
            # Wait for role to be available 
            print(" Waiting for role to be available...") 
            time.sleep(10)

            print(f" Created IAM role: {role_arn}") 
            return role_arn

        except ClientError as e: 
            raise LambdaDeploymentError(f"Failed to create IAM role: {e}") 
        
    def deploy_function(self, package_path: str, role_arn: str, update_if_exists: bool = True) -> Dict[str,Any]:
        """Deploy Lambda function""" 
        print(f" ~ Deploying Lambda, function: {self.function_name}") 
    
        # Load environment variables
        if self.dry_run:
            print(f" [DRY RUN] Would deploy function using {package_path} and role {role_arn}")
            return {'FunctionArn': f"arn:aws:lambda:{self.region}:123456789012:function:{self.function_name}"}
        env_vars = self.load_environment_config()
        self.deployment_config["environment_variables"] = env_vars

        # Read deployment package 
        with open(package_path, 'rb') as f: 
            zip_content = f.read()

        try: 
            # Try to get existing function
            response = self.lambda_client.get_function(FunctionName=self.function_name)

            if update_if_exists: 
                print(" E Updating existing function...")

                # Update function code 
                self.lambda_client.update_function_code(
                    FunctionName=self.function_name, 
                    ZipFile=zip_content
                )

                # Update function configuration 
                response = self.lambda_client.update_function_configuration( 
                    FunctionName=self.function_name,
                    Role=role_arn, 
                    Handler ="lambda_handler.handler", 
                    Runtime=self.deployment_config["runtime"], 
                    Timeout=self.deployment_config["timeout"], 
                    MemorySize=self.deployment_config["memory_size"], 
                    Environment={'Variables': env_vars }, 
                    Architectures=[self.deployment_config["architecture"]]
                )
            else: 
                print("X Function exists and update_if_exists is False") 
                return response['Configuration']
            
        except ClientError as e: 
            if e.response['Error']['Code'] != "ResourceNotFoundException": 
                raise

        # Create new function 
        print(" Creating new Lambda function...") 
        response = self.lambda_client.create_function(
            FunctionName=self.function_name, 
            Runtime=self.deployment_config["runtime"], 
            Role=role_arn, 
            Handler="lambda_handler.handler", 
            Code={'ZipFile': zip_content}, 
            Description=f"TextAnalyzer FastAPI service - {self.function_name}",
            Timeout=self.deployment_config["timeout"], 
            MemorySize=self.deployment_config["memory_size"],
            Environment={"Variables": env_vars},
            Architectures=[self.deployment_config["architecture"]]
        )
                           
        #Wait for function to be active 
        print(" Waiting for function to be active...")
        waiter = self.lambda_client.get_waiter('function_active') 
        waiter.wait(FunctionName=self.function_name)
        
        print(f" Function deployed successfully: {response['FunctionArn']}")
        return response
    
    def create_api_gateway(self, lambda_arn: str) -> Dict[str, Any]:
        """Create API Gateway HTTP API for Lambda"""
        print("Creating API Gateway")
        api_name = f"{self.function_name}-api"
		
		if self.dry_run:
            print(f" [DRY RUN] Would create API Gateway for function {self.function_name}")
            return {
                'api_id': 'dryrun-api-id',
                'api_endpoint': 'https://dryrun-api.execute-api.region.amazonaws.com',
                'integration_id': 'dryrun-integration-id',
                'stage_name': '$default'
            }
        try: 
            # Create HTTP API 
            api_response  = self.apigateway_client.create_api(
                Name=api_name, 
                ProtocolType="HTTP",
                Description=f"API Gateway for {self.function_name} Lambda function", 
                CorsConfiguration={
                    'AllowCredentials': False, 
                    'AllowHeaders': ['content-type', 'x-api-key', 'authorization'],
                    'AllowMethods': ['*'], 
                    'AllowOrigins': ['*'], 
                    'MaxAge': 300
                }
            )
            api_id = api_response['ApiId'] 
            api_endpoint = api_response['ApiEndpoint']

            # Create integration
            integration_response = self.apigateway_client.create_integration(
                ApiId=api_id,
                IntegrationType='AWS_PROXY', 
                IntegrationUri=f"arn:aws:apigateway:{self.region}:lambda:path/2015-03-31/functions/{lambda_arn}/invocations",
                PayloadFormatVersion='2.0'
            )

            integration_id = integration_response['IntegrationId']

            # Create route for all methods and paths 
            route_response = self.apigateway_client.create_route(
                ApiId=api_id,
                RouteKey='$default', 
                Target=f"integrations/{integration_id}"
            )

            # Create default stage
            stage_response = self.apigateway_client.create_stage(
                ApiId=api_id, 
                StageName='$default', 
                AutoDeploy=True
            )

            # Add Lambda permission for API Gateway
            try:
                self.lambda_client.add_permission(
                    FunctionName=self.function_name, 
                    StatementId=f"{api_id}-invoke-permission", 
                    Action='lambda:InvokeFunction', 
                    Principal='apigateway.amazonaws.com', 
                    SourceArn=f"arn:aws:execute-api:{self.region}:*:{api_id}/*/*"
                )
            except ClientError as e: 
                if e.response['Error']['Code'] != 'ResourceConflictException': 
                    raise
    # I
            print(f" API Gateway created: {api_endpoint}")
            return {
                'api_id': api_id, 
                'api_endpoint': api_endpoint, 
                'integration_id': integration_id, 
                'stage_name': '$default'
            }
        except ClientError as e: 
            raise LambdaDeploymentError (f"Failed to create API Gateway: {e}")

    def test_deployment(self, api_endpoint: str) -> bool: 
        """Test the deployed Lambda function""" 
        print(" Testing deployment...")

        import requests
        try:
            # Test health endpoint
            health_url = f"{api_endpoint}/health"
            response = requests.get(health_url, timeout=30)

            if response.status_code == 200:
                print(f" Health check passed: {response.json()}")
                return True
            else:
                print(f"X Health check failed: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            print(f" X Test failed: {e}")
            return False
        
    def cleanup_build(self):
        """Clean up build directory"""
        
        if self.build_dir.exists():
            shutil.rmtree(self.build_dir)
            print(" Build directory cleaned up")

    def get_deployment_info(self) -> Dict[str, Any]:
        """Get deployment information"""
        try:
            function_info = self.lambda_client.get_function(FunctionName=self.function_name)
            return {
                'function_name': self.function_name,
                'function_arn': function_info['Configuration']['FunctionArn'],
                'runtime': function_info['Configuration']['Runtime'],
                'last_modified': function_info['Configuration']['LastModified'],
                'state': function_info['Configuration']['State'],
                'memory_size': function_info['Configuration']['MemorySize'],
                "timeout": function_info['Configuration']['Timeout']
            }
        except ClientError:
            return {'function_name': self.function_name, 'deployed': False}

def main():
    """Main deployment script"""
    parser = argparse.ArgumentParser(description='Deploy TextAnalyzer Lambda function')
    parser.add_argument ('function_name', help='Lambda function name')
    parser.add_argument('--region', default='us-east-1', help='AWS region')
    parser.add_argument('--update', action='store_true', help='Update existing function')
    parser.add_argument("--create-api", action='store_true', help='Create API Gateway')
    parser.add_argument("--test", action='store_true', help="Test deployment")
    parser.add_argument("--cleanup", action='store_true', help="Cleanup build directory")
    parser.add_argument('--env-file', help="Environment file path")
	parser.add_argument('--dry-run', action='store_true', help="Simulate deployment without making changes")

    args = parser.parse_args()

    deployer = LambdaDeployer(args.function_name, args.region)
	deployer.dry_run = args.dry_run
    try:
        print(f" 4 Starting deployment of {args.function_name}")
        
        # Create deployment package 
        package_path = deployer.create_deployment_package()

        # Create or get IAM role 
        role_arn = deployer.create_lambda_role()

        # Deploy function 
        function_info = deployer.deploy_function(package_path, role_arn, args.update) 
        lambda_arn = function_info['FunctionArn']

        # Create API Gateway if requested 
        api_info = None 
        if args.create_api:
            api_info = deployer.create_api_gateway(lambda_arn)

        # Test deployment if requested 
        if args.test and api_info: 
            deployer.test_deployment(api_info['api_endpoint'])

        #Print deployment summary 
        print("\n" + "="*60)
        print(" & DEPLOYMENT SUCCESSFUL") 
        print("-"*60) 
        print(f"Function Name: {args.function_name}") 
        print(f"Function ARN: {lambda_arn}") 
        if api_info: 
            print(f"API Endpoint: {api_info['api_endpoint']}") 
            print(f"Health Check: {api_info['api_endpoint']}/health")
            print("-"*60)
    except Exception as e: 
        print(f"X Deployment failed {e}")
        sys.exit(1)
    finally:
        if args.cleanup and not args.dry_run:
            deployer.cleanup_build()
		elif args.cleanup and args.dry_run:
            print(" [DRY RUN] Would clean up build directory")

if __name__ == "__main__":
    main()

