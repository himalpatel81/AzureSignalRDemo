#To Run Lambda
1. Run python service first. 
2. 

python service_main.py

and then from another terminal run test_lambda

python .\test_lambda.py --url http://localhost:8000 --api-key dev-key-12345