pip install -r deployment_requirements.txt

python deploy_lambda.py {function-name}
