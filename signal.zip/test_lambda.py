#!/usr/bin/env python3
"""
Test script for validating Lambda deployment of TextAnalyzer FastAPI service 
Tests both local Lambda handler and deployed Lambda function
"""
import json 
import sys 
import os 
import requests 
import argparse 
from pathlib import Path 
from typing import Dict, Any, Optional
import traceback

class LambdaTester:
    """Test suite for Lambda deployment validation""" 
    def __init__(self, api_gateway_url: Optional[str] = None, api_key: Optional[str] = None): 
        self.api_gateway_url = api_gateway_url.rstrip("/") if api_gateway_url else None 
        self.api_key = api_key
        self.ai_dir = Path(__file__).parent
        print(f"setting ai path {self.ai_dir}")
        # Test payloads
        self.test_messages = {
            "political":{
                "content": "Vote for John Smith in the upcoming election! Authorized by Smith Campaign Committee.",
                 "expected_classification": "Political"
            },
            "nonprofit":{
                "content": "Help us fight hunger in our community. Donate to Food Bank Foundation, a 501(c)(3) nonprofit.", 
                "expected_classification": "NotForProfit"
            },
            "general":{
                "content": "Your appointment is confirmed for tomorrow at 2 PM. Contact us at info@clinic.com if you need to reschedule.",
                "expected_classification": "General"
            }
        }

    def test_local_lambda_handler(self) -> bool: 
        """Test the Lambda handler locally without AWS""" 
        print(" Testing Lambda handler locally...")
        try:
            # Add AI directory to path 
            sys.path.insert(0, str(self.ai_dir))
            
            # Set Lambda environment variable 
            os.environ["AWS_LAMBDA_FUNCTION_NAME"] = 'test-function'
                
            # Import handler 
            from lambda_handler import handler
            
            # Create mock context
            class MockContext:
                aws_request_id = "test-request-123" 
                function_name = "test-function" 
                function_version = "$LATEST" 
                invoked_function_arn = "arn:aws:lambda:us-east-1:123456789012:function:test-function" 
                memory_limit_in_mb = "1024" 
                remaining_time_in_millis = lambda self: 30000

            context = MockContext()
        
            # Test health endpoint API Gateway 2.0 format
            health_event = {
                "version":"2.0",
                "routeKey":"GET /health",
                "rawPath": "/health",
                "rawQueryString":"",
                "headers":{
                    "content-type":"application/json",
                    "host":"localhost"
                },
                "requestContext":{
                    "accountId": "123123123",
                    "appId":"test-api",
                    "domainName": "localhost",
                    "domainPrefix":"test",
                    "http":{
                        "method": "GET",
                        "path": "/health",
                        "protocol": "HTTP/1.1",
                        "sourceIp":"127.0.0.1",
                        "userAgent": "test-agent"
                    },
                    "requestId":"test-request-123",
                    "routeKey":"GET /health",
                    "stage":"test",
                    "time":"09/Apr/2015:12:34:56 +0000",
                    "timeEpoch": 1428582896000
                },
                "body": None,
                "isBase64Encoded": False
            }
    
            print(" Testing health endpoint...") 
            response =handler (health_event, context)
            if response["statusCode"] == 200:
                print(" Health endpoint test passed")
                body = json.loads(response["body"])
                print(f" Service status: {body.get('status', 'unknown')}")
                print(f"Version: {body.get('version', 'unknown')}")
            else:
                print(f" X Health endpoint failed: {response}") 
                return False
            
            print(" Local Lambda handler test completed successfully") 
            return True
        
        except Exception as e:
            print(f"X Local Lambda handler test failed: {e} - {traceback.format_exc()}") 
            return False
        finally:
            # Clean up environment
            if 'AWS_LAMBDA_FUNCTION_NAME' in os.environ:
                del os.environ['AWS_LAMBDA_FUNCTION_NAME']

    def test_local_analyze_endpoint(self) -> bool:
        """Test the /analyze endpoint locally through Lambda handler""" 
        print(" Testing /analyze endpoint locally through Lambda handler...")
        try: 
            # Add AI directory to path 
            sys.path.insert(0, str(self.ai_dir))

            # Set Lambda environment variable 
            os.environ["AWS_LAMBDA_FUNCTION_NAHE"] = 'test-function'

            # Import handler 
            from lambda_handler import handler

            # Create mock context 
            class MockContext:
                aws_request_id = "test-request-123" 
                function_name = "test-function" 
                function_version ="$LATEST" 
                invoked_function_arn = "arn:aws:lambda:us-east-1:123456789012:function:test-function" 
                memory_limit_in_mb = "1024" 
                remaining_time_in_millis = lambda self: 30000

            context = MockContext() 
            all_tests_passed= True

            # Test each message type through local Lambda 
            for test_name, test_data in self.test_messages.items(): 
                print(f" Testing {test_name} analysis through local Lambda...")

                # Create payload in MMSAnalysisRequest format
                payload ={
                    "content": { 
                        "text": test_data["content"], 
                        "images": [],
                        "emojis": []
                    },
                    "category": test_data["expected_classification"].lower(), 
                    "session_1d": f"test-{test_name}-123"
                }

                # Create API Gateway v2.0 event for POST /analyze
                analyze_event = {
                    "version": "2.0",
                    "routekey": "POST /analyze",
                    "rawPath": "/analyze",
                    "rawQueryString" : "",
                    "headers":{
                        "content-type": "applicat1on/json",
                        "host": "localhost"
                    },
                    "requestContext":{
                        "accountId": "123456789012",
                        "apiId": "test-api",
                        "domainllame": "localhost",
                        "domainPrefix": "test",
                        "http":{
                            "method": "POST",
                            "path": "/analyze",
                            "protocol": "HTTP/1.1",
                            "sourceIp": "127.0.0.1",
                            "userAgent": "test-agent"
                        },
                        "requestId": f"test-request-{test_name}",
                        "routeKey": "POST /analyze",
                        "stage": "test",
                        "time": "09/Apr/2815:12:34:56 40000",
                        "timeEpoch": 1428582896000
                    },
                    "body": json.dumps(payload),
                    "isBase64Encoded": False
                }


                try:
                    response = handler(analyze_event, context)
                    if response["statusCode"] == 200:
                        result = json.loads(response["body"])
                        success = result.get("success", False)
                        confidence = result.get("confidence_score", 0)
                        violations = result.get("violations", [])
                        suggested_message = result.get("suggested_message", "")

                        print(f"{test_name.title()} local Lambda test passed")
                        print(f"Success: {success}")
                        print(f"Confidence: {confidence:.1%}")
                        print(f"Violations found: {len(violations)}")
                        print(f"Suggested message: {suggested_message[:50]}{'...' if len(suggested_message) > 50 else ''}")

                        if violations:
                            print(f"Violations: {violations[:2]}{'...' if len(violations) > 2 else ""}")

                    else:
                        print(f" {test_name.title()} local Lambda test failed: {response['statusCode']}")

                        if "body" in response:
                            body = json.loads(response["body"]) if response["body"] else {}
                            print(f"Error: {body.get('message', 'Unknown error')}")
                        all_tests_passed = False

                except Exception as e:
                    print(f" {test_name.title()} local Lambda test error: {e}")
                    all_tests_passed = False

            # Test MMS content through local Lambda
            print("Testing MMS content through local Lambda...")
            mms_payload = {
                "content" :{
                    "text": "Check out this great offer! Valid until tomorrow.",
                    "images": [],
                    "emojis": [{
                        "emoji":" ",
                        "unicode_code": "U-1F389",
                        "description": "Party popper"
                    }]
                },
                "category": "general",
                "session id": "test-mms-123"
            }

            mms_event = {
                "version":"2.0",
                "routeKey":"POST /analyze",
                "rawPath": "/analyze",
                "rawQueryString":"",
                "headers":{
                    "content-type":"application/json",
                    "host":"localhost"
                },
                "requestContext":{
                    "accountId": "1323123123",
                    "appId":"test-api",
                    "domainName": "localhost",
                    "domainPrefix":"test",
                    "http":{
                        "method": "POST",
                        "path": "/analyze",
                        "protocol": "HTTP/1.1",
                        "sourceIp":"127.0.0.1",
                        "userAgent": "test-agent"
                    },
                    "requestId":"test-request-mms",
                    "routeKey":"POST /analyze",
                    "stage":"test",
                    "time":"09/Apr/2015:12:34:56 +0000",
                    "timeEpoch": 1428582896000
                },
                "body": json.dumps(mms_payload),
                "isBase64Encoded": False
            }

            try:
                response= handler(mms_event, context)
                if response["statusCode"] == 200:
                    result = json.loads(response["body"])
                    print(" MMS content local Lambda test passed")
                    print(f" Success: {result.get('success', False)}")
                    print(f"Confidence: {result.get('confidence_score', 0):.1%}")
                    print(f" Violations found: {len(result.get('violations', []))}")
                    print(f" Suggested message: {result.get('suggested_message','')[:50]}{'...' if len(result.get('suggested_message', '')) > 50 else ''}")
                else:
                    print(f" X MS content local Lambda test falled: (response['statusCode'])")
                    all_tests_passed = False
                
            except Exception as e:
                print(" MS content local Lambda test error: {e}") 
                all_tests_passed = False
            if all_tests_passed:
                print("All local /analyze endpoint tests completed successfully") 
            else:
                print("Some local /analyze endpoint tests failed")
            
            return all_tests_passed
        except Exception as e:
                print(f" Local /analyze endpoint test failed: {e})")
                return False 
        finally:
        # Clean up environment
            if 'AWS_LAMBDA_FUNCTION_NAME' in os.environt:
                del os.environ['AWS_LAMBDA_FUNCTION_NAME']

    def test_deployed_lambda (self) -> bool: 
        """Test the deployed Lambda function Via APT Catersymon """
        if not self.api_gateway_url: 
            print("No API Gateway URL")
            return True
        
        print(f"Testing  Deployed Lambda at {self.api_gateway_url}")

        try:
            #Test health endpoint
            response = requests.get(
                f"{self.api_gateway_url}/health",
                timeout = 30
            )
        
            if response.status_code == 200:
                health_data = response.json()
                print(" Health endpoint test passed")
                print(f" Service Status: {health_data.get('status','unknown')}")
                print(f" Authentication enabled: {health_data.get('details',{}).get('authentication_enabled','unknown')}")
                print(f" Guidelines enabled: {health_data.get('details',{}).get('shared_resources_loaded','unknown')}")
            else:
                print(f" Health endpoint failed {response.status_code} - {response.text}")

            if self.api_key:
                print("Testing Authentication")
                auth_response = requests.get(
                    f"{self.api_gateway_url}/auth/status",
                    headers={"X-API-Key": self.api_key},
                    timeout=30
                )

                if auth_response.status_code == 200:
                    auth_data = auth_response.json()
                    print(f" Auth enabled: {auth_data.get('authentication_enabled','unknown')}")
                    print(f" Valid Keys: {auth_data.get('valid_keys_count','unknown')}")
                else:
                    print(f" Auth failed: {auth_response.status_code}")
            
            print(" Deployed Lambda test completed successfully") 
            return True

        except requests.RequestException as e: 
            print(f"X Deployed Lambda test failed: {e}") 
            return False
        
    def test_classification_endpoints(self) -> bool:
        """Test the analyze functionality""" 
        if not self.api_gateway_url or not self.api_key: 
            print(" API Gateway URL or API key not provided, skipping analyze tests") 
            return True

        print("G Testing analyze endpoints...")

        headers ={
            "Content-Type": "application/json",
            "X-API-Key": self.api_key
        }
        
        all_tests_passed = True
        for test_name, test_data in self.test_messages.items(): 
            print(f" Testing {test_name} analysis...")
            
            #Create payload in MMSAnalysis Request
            payload = {
                "content": {
                    "text":test_data["content"],
                    "images":[],
                    "emojis":[]
                }, 
                "category":test_data["expected_classification"].lower(),
                "session_id": f"test-{test_name}-123"
            }

            try:
                response =requests.post(
                    f"{self.api_gateway_url}/analyze", 
                    json=payload, 
                    headers=headers,
                    timeout=30
                )
                if response.status_code == 200:
                    result = response.json()
                    success = result.get ("success", False) 
                    confidence = result.get("confidence_score", 0) 
                    violations = result.get("violations", []) 
                    suggested_message = result.get("suggested_message", "") 
                    
                    print(f"{test_name.title()} test passed") 
                    print(f" Success: {success}")
                    print(f" Violations found: {len(violations)}")
                    print(f" Confidence: {confidence:.1%}")
                    print(f" Suggest4ed Message: {suggested_message[:50]}{'...' if len(suggested_message) > 50 else ''}")
                    
                else:
                    print(f" X {test_name.title()} test failed: {response.status_code} - {response.text}") 
                    all_tests_passed = False
            
            except requests.RequestException as e:
                print(f" X {test_name.title()} test error: {e})")
                all_tests_passed = False

        if all_tests_passed:
            print(" All analysis tests completed successfully") 
        else:
            print("X Some analysis tests failed")
        
        return all_tests_passed

    def test_mms_content(self) -> bool: 
        """Test the MMS analysis endpoint""" 
        if not self.api_gateway_url or not self.api_key: 
            print(" API Gateway URL or API key not provided, skipping MMS content test") 
            return True

        print(" Testing MMS analysis endpoint...")
        headers ={
            "Content-Type": "application/json",
            "X-API-Key": self.api_key
        }

        # Simple MMS test payload with correct format
        mms_payload = {
            "content":{
                "text": "Check out this great offer! Valid until tomorrow.",
                "images": [],
                "emojis": [{
                    "emoji":" ",
                    "unicode_code": "U+1F389",
                    "description": "Party popper"
                    }
                ]
            },
            "category": "general",
            "session_id": "test-mms-123"
        }
        try:
            response= requests.post(
                f"{self.api_gateway_url}/analyze",
                json=mms_payload,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                print(" MMS analysis test passed")
                print(f"Success: {result.get("success", False)}")
                print(f"Confidence: {result.get('confidence_score', 0):.1%}")
                print(f"Violations found: {len(result.get('violations', []))}")
                return True
            else:
                print(f" X MMS content test failed: {response.status_code} - {response.text}") 
                return False
            
        except requests.RequestException as e: 
            print(f" X MMS test error: {e}") 
            return False

    def run_all_tests(self) -> bool:
        """Run complete test suite"""
        print("# Starting Lambda deployment test suite...")
        print("-" * 50)
        
        tests_passed= []

        # Test 1: Local Lambda handler
        tests_passed.append(self.test_local_lambda_handler())
        print()
        # Test 2: Deployed Lambda (if URL provided)
        tests_passed.append(self.test_deployed_lambda())
        print()
        # Test 3: Analyze endpoints (if URL and API key provided) 
        tests_passed.append(self.test_classification_endpoints()) 
        print()
        #Test4 : MMS content analysis (if url and api key provided)
        tests_passed.append(self.test_mms_content())

        print("=" * 50)
        total_tests = len(tests_passed)
        passed_tests = sum(tests_passed)

        if all(tests_passed):
            print(" All tests passed successfully!")
            print(f" Tests completed: {passed_tests}/{total_tests}")
            return True
        else:
            print("X Some tests failed")
            print(f" Tests passed: {passed_tests}/{total_tests}")
            return False
    
def main():
    parser = argparse.ArgumentParser(description="Test Lambda deployment of TextAnalyzer service")
    parser.add_argument("--url", help="API Gateway URL for deployed Lambda")
    parser.add_argument("--api-key", help="API key for authentication")
    parser.add_argument("--local-only", action="store_true", help="Run only local tests")

    args = parser.parse_args()
    # if args.local_only:
    # tester = LambdaTester()
    # success = tester.test_local_lambda_handler()
    # else: 
    tester= LambdaTester(args.url, args.api_key) 
    success = tester.run_all_tests()
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()

