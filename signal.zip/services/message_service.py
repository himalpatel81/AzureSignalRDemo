import asyncio
import sys
from typing import List, Optional
import structlog
from config import Config
from models.message import  Change, ComplianceAnalysis, ContentValidation, GuidelineApplication, MMSAnalysisRequest, MultimodalCoherence, ResponseFormat, ValidationResults
from services.openai_service import OpenAIService
from services.guideline_service import GuidelineService
from utils.logger import (log_error_with_context)
import time
import traceback

class MessageService:
    """Main Service for Message Generation and Optimization"""

    #Class-level shared guideline service instance
    _shared_guideline_service: Optional[GuidelineService] = None
    _initialization_lock= asyncio.Lock();
    
    def __init__(self, config:Config):
        self.config = config
        self.logger = structlog.get_logger("message_service")
        self.openai_service = OpenAIService(config)
        #self.guideline_service = GuidelineService()

        self.logger.info("Message Service initialized")

    @classmethod
    async def initialize_shared_resources(cls):
        """
        Initialize Guideline Service once at application start up.
        """
        async with cls._initialization_lock:
            if cls._shared_guideline_service is None:
                logger = structlog.get_logger("message_service")
                logger.info("Initializing Shared Resources")
                
                cls._shared_guideline_service = GuidelineService()

                #Log Stats if required. 
        
    @classmethod
    async def cleanup_shared_resources(cls):
        """
        Clean up shared resources on application shutdown.
        """
        logger = structlog.get_logger("message_service")
        if cls._shared_guideline_service is not None:
            logger.info("Cleaning up Shared Resources")
            cls._shared_guideline_service = None

    @property
    def guideline_service(self) -> GuidelineService:
        """
        Get the shared guideline service instance.
        """

        if self._shared_guideline_service is None:
            raise RuntimeError(
                "Shared guideline service is not initialized",
                "Call initialize_shared_resources() in FASTAPI's lifespan context manager."
            )
        
        return self._shared_guideline_service

    async def process_mms_message(self, request: MMSAnalysisRequest) -> ResponseFormat:
        """Process MMS message with user-provided category
        Args:
            request: MMS Analysis request with user-provided category

        Returns:
            Complete Analysis result with MMS-specific analysis
        """
        self.logger.info("Starting MMS message processing") 
        start_time =time.time()
        try: 
            # Log MMS request details 
            self.logger.info( "MMS processing request", 
                             category=request.category, 
                             text_length=len(request.content.text), 
                             image_count=len(request.content.images), 
                             emoji_count=len(request.content.emojis), 
                             session_id=request.session_id
            )

            
            # Step 1: Load guidelines for user-provided category 
            self.logger.debug(f"Loading guidelines for category: {request.category})") 
            guidelines = self.guideline_service.get_guidelines_for_category(request.category) 
            self.logger.debug(f"Loaded (len(guidelines)] guidelines")

            self.logger.debug("Starting comprehensive MMS analysis") 
            mms_analysis = await self.openai_service.analyze_mms_content(
                content_text=request.content.text,
                images=request.content.images,
                emojis=request.content.emojis,
                category=request.category,
                guidelines=guidelines
            )
            return mms_analysis
            # result = await self.parse_mms_analysis(mms_analysis)
            # return result
            
        except Exception as e:
            processing_time_ms = int((time.time() - start_time) * 1000)
            traceback.print_exc() 
            log_error_with_context(
                self.logger,
                e,
                {
                    "category": request.category,
                    "text_length": len(request.content.text),
                    "image_count": len(request.content.images),
                    "emoji_count": len(request.content.emojis),
                    "processing_time_ms": processing_time_ms
                },
                'process_mms_message'
            )

            # Return error result
            return ResponseFormat(
                success=False,
                violations=[],
                suggested_message="",
                justification="",
                improvement_areas=[],
                compliance_improvements=[],
                impact_score=0,
                changes_made=[],
                guideline_applications=[],
                validation_results=[],
                multimodal_coherence=[],
                compliance_analysis=[],
                readability_score=0,
                confidence_score=0,
                #processing_time_ms=processing_time_ms
                error_message=str(e)
            )
    
    async def parse_mms_analysis(self, data: dict) -> ResponseFormat:
        return ResponseFormat(
            success=True,
            violations=data["violations"],
            suggested_message=data["suggested_message"],
            justification=data["justification"],
            improvement_areas=data["improvement_areas"],
            compliance_improvements=data["compliance_improvements"],
            impact_score=data["impact_score"],
            changes_made=[Change(**c) for c in data["changes_made"]],
            guideline_applications=[GuidelineApplication(**g) for g in data["guideline_applications"]],
            validation_results=ValidationResults(
                text_content=ContentValidation(**data["validation_results"]["text_content"]),
                image_content=ContentValidation(**data["validation_results"]["image_content"]),
                emoji_content=ContentValidation(**data["validation_results"]["emoji_content"]),
            ),
            multimodal_coherence=MultimodalCoherence(**data["multimodal_coherence"]),
            compliance_analysis=ComplianceAnalysis(
                text_content=ContentValidation(**data["compliance_analysis"]["text_content"]),
                image_content=ContentValidation(**data["compliance_analysis"]["image_content"]),
                emoji_content=ContentValidation(**data["compliance_analysis"]["emoji_content"]),
            ),
            readability_score=data["readability_score"],
            confidence_score=data["confidence_score"]
    )