import structlog
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from models.message import CategoryLoader, Guideline, GuidelineExample, ValidationCriterion
import os
from utils.logger import log_error_with_context

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GuidelineService:
    """Service for loading and managing guidelines from file system"""

    def __init__(self):
        self.logger = structlog.get_logger("guideline_service")
        self.guideline_cache = {}
        self.guidelines_dir = Path(__file__).parent.parent / "guidelines"
        self.data : Optional[CategoryLoader] = None
        # self.categories_path = categories_path
        # self.guidelines_dir = guidelines_dir
        # self.guideline_cache: Dict[str, List[Rule]] = {}

        #Load all guidelines on initialization
        self._load_all_guidelines()

        # self.logger.info("Guideline service initialized",
        #                  total_guidelines = sum(len(guidelines) for guidelines in self.guideline_cache.values()))

    def _load_all_guidelines(self):
        """Load all guidelines files into cache"""
        try:
            with open(os.path.join(self.guidelines_dir, "categories.json"), 'r') as f:
                categorieslist = json.load(f)
            self.data = CategoryLoader(**categorieslist)

        except Exception as e:
            logger.error(f"Failed to read categories file: {e}")
            return

        for category in self.data.categories:
            try:
                if not category.active:
                    continue

                guidelines = self._load_guidelines_file(category.fileName)
                self.guideline_cache[category.name.lower()] = guidelines

                #self.logger.info(f"Loaded guidelines for category: {category}")
            except Exception as e:
                logger.warning(f"Failed to load guidelines for {category}: {e}")
        logger.info(f"Loaded {len(self.guideline_cache)} Guidelines.")

    def _load_guidelines_file(self, category: str) -> List[Guideline]:
        #filepath = os.path.join(self.guidelines_dir, f"{category}.json")
        filepath = self.guidelines_dir / f"{category}"

        try:
            # if not filepath.exists():
            #     self.logger.warning(f"Guideline")
            #     return []

            with open(filepath, 'r',encoding='utf-8') as file:
                data = json.load(file)
            
            guidelines = []
            for guideline_data in data:
                try:
                    #Parse validation Criteria
                    validation_criteria = []
                    if 'validation_criteria' in guideline_data:
                        for criterion_data in guideline_data['validation_criteria']:
                            validation_criteria.append(ValidationCriterion(**criterion_data))
                    
                    # Parse effective examples 
                    effective_examples = [] 
                    if 'effective_examples' in guideline_data: 
                        for example_data in guideline_data['effective_examples']: 
                            effective_examples.append(GuidelineExample(**example_data))

                    # Parse ineffective examples 
                    ineffective_examples = [] 
                    if 'ineffective_examples' in guideline_data: 
                        for example_data in guideline_data["ineffective_examples"]: 
                            ineffective_examples.append(GuidelineExample(**example_data))

                    # Create guideline object guideline
                    guideline = Guideline( 
                        rule_id=guideline_data['rule_id'], 
                        rule_title=guideline_data['rule_title'], 
                        rule_statement=guideline_data['rule_statement'], 
                        detailed_description=guideline_data['detailed_description'],
                        compliance_level=guideline_data['compliance_level'], 
                        severity=guideline_data['severity'], 
                        validation_criteria=validation_criteria, 
                        best_practices=guideline_data.get('best_practices', []), 
                        effective_examples=effective_examples, 
                        ineffective_examples=ineffective_examples
                    )
                    guidelines.append(guideline)
                except Exception as e:
                    self.logger.error(
                        "Failed to parse guideline", 
                        error=str(e), 
                        guideline_data=guideline_data, 
                        file=filepath
                    )
            self.logger.debug(
                    f"Loaded {len(guidelines)} guidelines from {filepath}", 
                    file=filepath, 
                    count=len(guidelines)
            )
            
            return guidelines
        
        except Exception as e:
                log_error_with_context(
                    self.logger, 
                    e, 
                    {"file_path":str(filepath)}, 
                    "load_guidelines_file"
                )    

            # validation_criteria = [ValidationCriterion(**vc) for vc in data.get("validation_criteria", [])]
            # rule = Rule(
            #     rule_id=data["rule_id"],
            #     rule_title=data["rule_title"],
            #     rule_statement=data["rule_statement"],
            #     compliance_level=data["compliance_level"],
            #     severity=data["severity"],
            #     active=data["active"],
            #     validation_criteria=validation_criteria
            # )
            # return [rule]

    def get_guidelines_for_category(self, category: str) -> List[Guideline]:
        category = category.strip().lower()
        general = self.guideline_cache.get("general", [])
        if category == "general":
            return general
        specific = self.guideline_cache.get(category.lower(), [])
        return general + specific
