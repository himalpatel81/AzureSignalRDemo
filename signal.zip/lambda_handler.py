"""
AWS Lambda Handler
"""

import os
import sys
import asyncio
import json
from typing import Dict, Any
import structlog
from mangum import Mangum

sys.path.insert(0,os.path.dirname(__file__))


from service_main import app as original_app
from fastapi import FastAPI 
from services.message_service import MessageService

def is_lambda_environment() -> bool: 
    """Detect if running in AWS Lambda environment""" 
    return bool(os.environ.get('AWS_LAMBDA_FUNCTION_NAME'))

def configure_lambda_logging():
    """Configure structured logging for AWS Lambda (Cloudwatch)""" 
    if is_lambda_environment(): 
        # Lambda-specific logging configuration 
            structlog.configure(
                processors=[
                    structlog.contextvars.merge_contextvars, 
                    structlog.processors.add_log_level, 
                    structlog.processors.TimeStamper(fmt="ISO"), 
                    structlog.processors.JSONRenderer()
                ],
                wrapper_class=structlog.make_filtering_bound_logger(20), #INFO level 
                logger_factory=structlog.WriteLoggerFactory(), 
                context_class=dict, 
                cache_logger_on_first_use=True,
) 
    # For local development keep existing logging configuration

class LambdaFastAPIHandler:
    """
    Lambda-compatible FastAPI handler with initialization management 
    Provides seamless operation in both local and Lambda environments
    """
    def __init__ (self, fastapi_app): 
        self.logger = structlog.get_logger("lambda_handler") 
        self._initialized = False 
        # self.app= fastapi_app 
        
        self._initialization_lock = asyncio.Lock()

        # Configure logging for Lambda environment 
        configure_lambda_logging()
        
        # Create Mangum adapter (only used in Lambda) 
        if is_lambda_environment(): 
            #CReate a Lambda Specific Fast API app without lifespan
            lambda_app = FastAPI(
                title=fastapi_app.title,
                description= fastapi_app.description,
                version=fastapi_app.version,
                docs_url=fastapi_app.docs_url,
                redoc_url= fastapi_app.redoc_url
                #No lifespan for Lambda
            )

            #Copy Routes from Original App
            lambda_app.router = fastapi_app.router
            lambda_app.middleware_stack = fastapi_app.middleware_stack
            lambda_app.exception_handlers = fastapi_app.exception_handlers

            self.mangum = Mangum(
                lambda_app,
                lifespan="off", # Disable FastAPI lifespan in Lambda 
                api_gateway_base_path=None, # Auto-detect from event 
                text_mime_types=[
                    "application/json",
                    "application/javascript",
                    "application/xml",
                    "application/vnd.api+json"
                ]
            )
            self.logger.info("Lambda handler initialized with Mangum adapter")
        else:
            self.mangum= None
            self.logger.info("Handler initialized for local development mode")

    async def initialize_shared_resources(self):
        """Initialize shared resources for Lambda cold starts""" 
        async with self._initialization_lock:
            if not self._initialized and is_lambda_environment(): 
                try:
                    self.logger.info("Initializing shared resources for Lambda cold start")

                    # Initialize the same shared resources as local mode 
                    await MessageService.initialize_shared_resources()
                    
                    #Import and set global variables that FASTAPI expects
                    from config import Config
                    from auth import AuthenticationService
                    import service_main

                    config = Config()

                    #Set the global variables that /analyze endpoint checks
                    service_main.message_service = MessageService(config)
                    service_main.auth_service = AuthenticationService(config)

                    self._initialized = True 
                    self.logger.info("Lambda cold start initialization completed successfully") 
                    self.logger.info(f"Global message_service set: {service_main.message_service is not None}") 
                except Exception as e:
                    self.logger.error(
                        "Failed to initialize shared resources in Lambda",
                        error=str(e),
                        error_type=type(e).__name__
                    )
                    raise

    def __call__(self, event: Dict[str, Any], context: Any) -> Dict[str, Any]:
        """
        AWS Lambda entry point
        Handles both API Gateway and direct invocation events
        """
        if not is_lambda_environment():
            raise RuntimeError("Lambda handler called outside Lambda environment")
        # try: 
        #     # Log the incoming event (for debugging) 
        #     self.logger .debug(
        #         "Lambda invocation started",
        #         request_id=context.aws_request_id if context else "unknown", 
        #         function_name=context.function_name if context else "unknown",
        #         remaining_time_ms=0
        #         #remaining_time_ms=context.get_remaining_time_in_millis() if context else 0
        #     )

        #     # Initialize shared resources on first invocation (cold start) 
        #     if not self._initialized: 
        #         await self.initialize_shared_resources()

        #     # Process the request through Mangum 
        #     response = await self.mangum(event, context)
        #     self.logger.info(
        #         "Lambda invocation completed successfully",
        #         request_id=context.aws_request_id if context else "unknown", 
        #         status_code=response.get("statusCode", "unknOwn")
        #     )
        if not self._initialized:
            import threading
            init_result=[None]
            init_error=[None]

            def init_in_thread():
                try:
                    loop= asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        loop.run_until_complete(self.initialize_shared_resources())
                        init_result[0] = True
                    finally:
                        loop.close()
                except Exception as e:
                    init_error[0] = e
            
            thread = threading.Thread(target=init_in_thread)
            thread.start()
            thread.join(timeout=30)

            if init_error[0]:
                raise init_error[0]
            if not init_result[0]:
                raise RuntimeError("Initialization Timed Out")
            
        try:
            return self.mangum(event,context)
    
        except Exception as e:
            # Log the error with full context
            self.logger.error(
                "Lambda invocation failed",
                error=str(e),
                error_type=type(e).__name__,
                request_id=context.aws_request_id if context else "unknown",
                event_type=event.get("version", "unknown") if isinstance(event, dict) else "unknown"
            )
            # Return error response in API Gateway format
            return{
                "statusCode": 500,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
                },
                "body": json.dumps({
                    "success": False,
                    "error": "Internal server error",
                    "message": str(e),
                    "request_id": context.aws_request_id if context else "unknown"
                })
            }

# Create the handler instance
lambda_fastapi_handler = LambdaFastAPIHandler(original_app)
def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main AWS Lambda handler function 
    This is the entry point that AWS Lambda will call
    """
    #The handler is now synchronous so we can call it direclty
    return lambda_fastapi_handler(event, context)

# For local testing of the Lambda handler
if __name__ ==  "__main__":
    print("Lambda handler module loaded successfully")
    print(f"Running in Lambda environment: fis_lambda_environment()?")

    if not is_lambda_environment():
        print("For local FastAPI development, run: python optimized_ pythonservice.py")
        print("For Lambda testing, use: aws lambda invoke --function-name your-function")
