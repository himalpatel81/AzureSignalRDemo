"""
Lambda-specific configuration overrides for TextAnalyzer service 
Provides environment-specific settings while maintaining compatibility
"""
import os 
from typing import Optional 
from config import Config

class LambdaConfig(Config): 
    """
    Lambda-optimized configuration that extends the base Config 
    Automatically detects Lambda environment and applies appropriate overrides
    """
    def __init__(self):
        # Initialize base configuration first 
        super().__init__()
    
        # Apply Lambda-specific overrides if in Lambda environment 
        if self._is_lambda_environment(): 
            self._apply_lambda_overrides()

    def _is_lambda_environment(self) -> bool: 
        """Check if running in AWS Lambda environment""" 
        return bool(os.environ.get("AWS_LAMBDA_FUNCTION_NAME"))
    
    def _apply_lambda_overrides(self): 
        """Apply Lambda-specific configuration overrides"""
        #--= Logging Configuration ===
        # Disable file logging in Lambda (use Cloudwatch instead) 
        self.log_file = None
        
        # Set appropriate log level for Lambda 
        self.log_level = os.environ.get('LAMBDA_LOG_LEVEL', 'INFO')

        # === Performance Configuration == 
        # # Disable Redis caching in Lambda (use in-memory instead) 
        self.enable_caching = False

        # Reduce OpenAI timeout to leave buffer for Lambda timeout 
        lambda_timeout = int(os.environ.get("AWS_LAMBDA_FUNCTION_TIMEOUT", "30"))  
        self.openai_timeout = min(self.openai_timeout, lambda_timeout - 5)

        # === Application Configuration === 
        # # Optimize for Lambda cold start performance 
        self.max_message_length = int(os.environ.get("LAMBDA_MAX_MESSAGE_LENGTH",str(self.max_message)))

        #--= Authentication Configuration === 
        # Authentication remains enabled but can be overridden 
        self.enable_authentication = os.environ.get('LAMBDA_ENABLE_AUTH', str(self.enable_authentication)).low() == 'true'

        # Override API keys from Lambda environment variables 
        if 'LAMBDA API KEYS' in os.environ: 
            self.api_keys = os.environ["LAMBDA API_KEYS"]

        # Override API key header if specified 
        if 'LAMBDA API_KEY HEADER' in os.environ: 
            self.api_key_header = os.environ[ 'LAMBDA API_KEY_HEADER']

        # === OpenAI Configuration
        # Override OpenAI settings from Lambda environment 
        if 'LAMBDA OPENAI_API_KEY' in os.environ: 
            self.openai_api_key = os.environ['LAMBDA_OPENAI_APT_KEY']

        if 'LAMBDA OPENAI_MODEL' in os.environ: 
            self.openai_model = os.environ["LAMBDA_OPENAI_MODEL"]

        if 'LAMBDA OPENAI _TIMEOUT' in os.environ: 
            self.openai_timeout = int(os.environ['LAMBDA_OPENAI_TIMEOUT'])

        # -==- Feature Flags for Lambda ===
        # These can be controlled via environment variables
        if 'LAMBDA ENABLE_MESSAGE_OPTIMIZATION' in os.environ:
            self.enable_message_optimization = os.environ['LAMBDA_ENABLE_MESSAGE_OPTIMIZATION'].lower

        if 'LAMBDA ENABLE_DETAILED_ANALYSIS' in os.environ:
            self.enable_detailed_analysis = os.environ["LAMBDA_ENABLE_DETAILED_ANALYSIS"].lower() == 'true'
        
        if 'LAMBDA ENABLE RULE_BASED_COMPLIANCE' in os.environ:
            self.enable_rule_based_compliance = os.environ["LAMBDA_ENABLE_RULE_BASED_COMPLIANCE"].lower() == 'true'

    def get_lambda_specific_config(self) -> dict:
        """Get Lambda-specific configuration for debugging"""
        return {
            "is_lambda_environment": self._is_lambda_environment(),
            "lambda_function_name": os.environ.get("AWS_LAMBDA_FUNCTION_NAME"),
            "lambda_function_version": os.environ.get("AWS_LAMBDA_FUNCTION_VERSION"),
            "lambda_log_group": os.environ.get("AWS_LAMBDA_LOG_GROUP_NAME"),
            "lambda_memory_size": os.environ.get("AWS_LAMBDA_FUNCTION_MEMORY_SIZE"),
            "lambda_timeout": os.environ.get( 'AWS LAMBDA FUNCTION TIMEOUT'),
            "overrides_applied": {
                "log_file_disabled": self.log_file is None,
                "caching_disabled": not self.enable_caching,
                "openai_timeout_adjusted": self.openai_timeout,
                "authentication_enabled": self.enable_authentication
            }
        }

def get_config() -> Config:
    """
    Factory function to get the appropriate configuration
    Returns LambdaConfig in Lambda environment, regular Config otherwise
    """
    
    if os.environ.get('AWS_LAMBDA_FUNCTION_NAME'):
        return LambdaConfig()
    else:
        return Config()

#For backward compatibility and easy importing
lambda_config = get_config()
