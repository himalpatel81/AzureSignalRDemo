"""
Authentication models and data structures
"""

from datetime import datetime, timezone
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field

class AuthenticationRequest(BaseModel):
    """Model for authentication request details"""
    api_key: str = Field(..., description="API key provided in request")
    client_ip: Optional[str] = Field(None, description="Client IP address")
    user_agent: Optional[str] = Field(None, description="Client user agent")
    timestamp: datetime = Field(default_factory=datetime.now(timezone.utc), description="Request timestamp")

class AuthenticationResult(BaseModel):
    """Model for authentication result"""
    success: bool = Field(..., description="Whether authentication succeeded")
    api_key_valid: bool = Field(..., description="Whether the API key is valid")
    client_ip: Optional[str] = Field(None, description="Client IP address")
    error_message: Optional[str] = Field(None, description="Error message if authentication failed")
    timestamp: datetime = Field(default_factory=datetime.now(timezone.utc), description="Authentication timestamp")

class ApiKeyInfo(BaseModel):
    """Model for API key information"""
    key_id: str = Field(..., description="Identifier for the API key")
    key_value: str = Field(..., description="The actual API key value")
    description: Optional[str] = Field(None, description="Description of the API key usage")
    is_active: bool = Field(default=True, description="Whether the API key is active")
    created_at: datetime = Field(default_factory=datetime.now(timezone.utc), description="When the key was created")
    last_used: Optional[datetime] = Field(None, description="When the key was last used")

class AuthenticationStatus(BaseModel): 
    """Model for authentication status response""" 
    authentication_enabled: bool = Field(..., description="Whether authentication is enabled") 
    header_name: str = Field(..., description="Expected API key header name") 
    valid_keys_count: int = Field(..., description="Number of configured valid API keys") 
    detailed_errors: bool = Field(..., description="Whether detailed error messages are enabled") 
    timestamp: datetime = Field(default_factory=datetime.now(timezone.utc), description="Status timestamp")



class AuthenticationError(Exception): 
    """Custom exception for authentication failures"""
    def __init__(
        self,
        message: str, 
        status_code: int = 401, 
        headers: Optional[Dict[str, str]] = None, 
        detail: Optional[Dict[str, Any]] = None
    ):
        self.message= message 
        self.status_code = status_code 
        self.headers = headers or {} 
        self.detail = detail or {}
        super().__init__(self.message)

class ApiKeyMissingError(AuthenticationError): 
    """Exception for missing API key"""
    def __init__(self, header_name: str): 
        super().__init__(
            message=f"API key missing: {header_name} header is required", 
            status_code=401, 
            detail={"error_type": "missing_api_key", "required_header": header_name}
        )

class ApiKeyInvalidError(AuthenticationError): 
    """Exception for invalid API key"""
    def __init__(
        self, 
        provided_key: Optional[str] = None, 
        detailed_errors: bool = False
        ): 
        if detailed_errors and provided_key: 
            message = f"Invalid API key: '{provided_key}'" 
            detail=  {"error_type": "invalid_api_key", "provided_key": provided_key}
        else: 
            message = "Invalid API key" 
            detail = {"error_type": "invalid api key"}
        
        super().__init__ (
            message=message, 
            status_code=401, 
            detail=detail
        )

class AuthenticationDisabledError(AuthenticationError): 
    """Exception when trying to authenticate but auth is disabled"""
    def __init__(self): 
        super().__init__(
            message="Authentication is disabled", 
            status_code=500, 
            detail={"error_type": "authentication_disabled"}
        )

