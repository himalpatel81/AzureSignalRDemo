"""
Authentication service for API key validation
"""

import structlog 
from datetime import datetime, timezone 
from typing import List, Optional, Dict, Any 
from fastapi import Request
from config import Config 
from auth.models import( 
    ApiKeyInvalidError,
    AuthenticationRequest, 
    AuthenticationResult, 
    ApiKeyInfo, 
    AuthenticationStatus, 
    ApiKeyMissingError, 
    AuthenticationDisabledError
)
from utils.logger import log_error_with_context

class AuthenticationService: 
    """Service for handling API key authentication"""
    def __init__(self, config: Config): 
        self.config = config 
        self.logger = structlog.get_logger ("authentication_service")

        # Initialize with configuration 
        self.valid_keys = config.get_valid_api_keys() 
        self.header_name = config.api_key_header 
        self.enabled = config.enable_authentication 
        self.detailed_errors = config.authentication_error_detail

        self.logger.info(
            "Authentication service initialized", 
            enabled=self.enabled, 
            header_name=self.header_name, 
            valid_keys_count=len(self.valid_keys), 
            detailed_errors=self.detailed_errors
        )

    def authenticate_request(self, request: Request) -> AuthenticationResult:
        """Authenticate a FastAPI request using API key
        Args:
            request: FastAPI request object
        Returns:
            AuthenticationResult with validation details
        Raises:
            ApiKeyMissingError: If API key header is missing 
            ApiKeyInvalidError: If API key is invalid 
            AuthenticationDisabledError: If authentication is disabled but required
        """
        print(f"Himal - Authenticating Request - {self.enabled}")
        try:
            # Check if authentication is enabled if not self. enabled:

            if not self.enabled: 
                self.logger.debug("Authentication disabled, allowing request")
                return AuthenticationResult(
                    success=True, 
                    api_key_valid=True, 
                    client_ip=self._get_client_ip(request), 
                    timestamp=datetime.now(timezone.utc)
                )
            
            # Extract API key from headers 
            api_key = self._extract_api_key(request) 
            client_ip = self._get_client_ip(request)
            
            # Log authentication attempt
            self.logger.info(
                "Authentication attempt", 
                client_ip=client_ip, 
                has_api_key=api_key is not None, 
                header_name=self.header_name
            )
            
            # Validate API key
            if not api_key:
                self.logger.warning(
                    "Authentication failed: missing API key", 
                    client_ip=client_ip, 
                    header_name=self.header_name
                )
                raise ApiKeyMissingError(self.header_name)

            # Check if API key is valid 
            is_valid = self._validate_api_key(api_key)
            
            if not is_valid:
                self.logger.warning(
                    "Authentication failed: invalid API key", 
                    client_ip=client_ip, 
                    api_key_preview=api_key[:8] + "..."  if len(api_key) > 8 else api_key
                )
                raise ApiKeyInvalidError(api_key, self.detailed_errors)
            
            #Success
            self.logger.info(
                "Authentication successful", 
                client_ip=client_ip, 
                api_key_preview=api_key[:8] +"..." if len(api_key) > 8 else api_key )
            
            return AuthenticationResult ( 
                success=True, 
                api_key_valid  = True, 
                client_ip=client_ip, 
                timestamp=datetime.now(timezone.utc)
            )
        except (ApiKeyMissingError, ApiKeyInvalidError, AuthenticationDisabledError): # Re-raise authentication errors
            raise
        except Exception as e:
            # Log unexpected errors 
            log_error_with_context(
                self.logger,
                e,
                {
                    "client_ip": self._get_client_ip(request), 
                    "header_name": self.header_name
                },
                "authenticate_request"
            )
            #Return generic authentication failure 
            return AuthenticationResult(
                success=False, 
                api_key_valid=False,
                client_ip=self._get_client_ip(request), 
                error_message=f"Authentication error: {str(e)}",
                timestamp=datetime.now(timezone.utc)
            )
        
    def _extract_api_key(self, request: Request) -> Optional[str]: 
        """Extract API key from request headers""" 
        return request.headers.get(self.header_name)
    
    def _get_client_ip(self, request: Request) -> Optional[str]: 
        """Get client IP address from equest""" 
        # Check for forwarded headers (common in load balancers) 
        forwarded_for = request.headers.get ("X-Forwarded-For") 
        if forwarded_for: 
            return forwarded_for.split(",")[0].strip()

        # Check for real IP header
        real_ip = request.headers.get("X-Real-IP") 
        if real_ip:
            return real_ip
        
        # Fall back to client host 
        return request.client.host if request.client else None

    def _validate_api_key(self, api_key: str) -> bool: 
        """Validate API key against configured valid keys""" 
        return api_key in self.valid_keys
    
    def get_authentication_status(self) -> AuthenticationStatus: 
        """Get current authentication configuration status""" 
        return AuthenticationStatus(
            authentication_enabled=self.enabled, 
            header_name=self.header_name, 
            valid_keys_count=len(self.valid_keys), 
            detailed_errors=self.detailed_errors, 
            timestamp=datetime.now(timezone.utc)
        )

    def validate_api_key_format(self, api_key: str) -> Dict[str, Any]:
        """
        Validate API key format and return analysis
        
        Args:
            api_key: API key to validate
        Returns:
            Dictionary with validation results
        """
        validation_result={
            "valid_format": True, 
            "length": len(api_key), 
            "has_special_chars": False, 
            "has_numbers": False, 
            "has_letters": False, 
            "recommendations":[]
        }
        
        # Check minimum length
        if len(api_key) < 8: 
            validation_result["valid_format"] = False 
            validation_result[ "recommendations"].append("API key should be at least characters long") 

        # Check character composition 
        validation_result["has_special_chars"] = any(not c.isalnum() for c in api_key) 
        validation_result["has_numbers"] = any(c.isdigit() for c in api_key) 
        validation_result["has_letters"] = any(c.isalpha() for c in api_key)

        # Recommendations for stronger keys 
        if not validation_result["has_special_chars"]: 
            validation_result ["recommendations"].append("Consider including special characters for stronger security")

        if not validation_result ["has_numbers"]: 
            validation_result["recommendations"].append("Consider including numbers for stronger security")

        if not validation_result["has_letters"]: 
            validation_result["recommendations"].append("Consider including letters for stronger security")

        return validation_result
    
    def generate_api_key_suggestions(self, count: int =3) -> List[str]:
        """Generate suggested API keys for development/testing
        Args:
            count: Number of suggestions to generate
        Returns: 
            List of suggested API keys
        """
        import secrets 
        import string
        suggestions = []

        for i in range(count): 
            # Generate a secure random API key I 
            alphabet = string.ascii_letters + string.digits + "-_"
            api_key = ''.join(secrets.choice(alphabet) for _ in range(32)) 
            suggestions.append(api_key)
        
        return suggestions

    def refresh_configuration(self, config: Config):
        """
        Refresh authentication configuration from updated config
        Args:
            config: Updated configuration object
        """
        old_config ={
            "enabled": self.enabled,
            "header_name": self.header_name,
            "valid keys count": len(self.valid_keys)
        }
        # Update configuration
        self.config = config
        self.valid_keys = config.get_valid_api_keys()
        self.header_name = config.api_key_header
        self.enabled = config.enable_authentication
        self.detailed_errors = config.authentication_error_detail
        self.logger.info(
            "Authentication configuration refreshed",
            old_config =  old_config,
            new_config={
                "enabled": self.enabled,
                "header_name": self.header_name,
                "valid keys count": len(self.valid_keys)
            }
        )


