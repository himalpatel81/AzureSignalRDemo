"""
Authentication module for Text Analyzer AI Classification Engine 
"""
from .models import ( 
    AuthenticationRequest, 
    AuthenticationResult, 
    ApiKeyInfo,
    AuthenticationStatus, 
    AuthenticationError,
    ApiKeyMissingError, 
    ApiKeyInvalidError,
    AuthenticationDisabledError
)

from .service import AuthenticationService 
from .middleware import ApiKeyAuthenticationMiddleware, create_auth_middleware
__all__= [
"AuthenticationRequest",
"AuthenticationResult",
"ApiKeyInfo",
"AuthenticationStatus",
"AuthenticationError",
"ApiKeyMissingError",
"ApiKeyInvalidError",
"AuthenticationDisabledError",
"AuthenticationService",
"ApiKeyAuthenticationMiddleware",
"create_auth_middleware"
]
